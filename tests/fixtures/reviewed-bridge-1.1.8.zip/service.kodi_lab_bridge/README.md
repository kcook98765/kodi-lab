# Kodi Lab narrow bridge

This ordinary Kodi service add-on provides an authenticated identity anchor,
capability verification and bounded screenshots for approved Kodi Lab
external-development targets and reviewed production targets. Installation is
manual. Configure only the administrator-allowlisted bridge port, enter the
show-once pairing token locally and complete pairing and explicit provenance
confirmation in Kodi Lab Web administration.

Production use requires the exact independently reviewed ZIP and checksum,
reviewed-build registration, one-time pairing and current revision-bound
least-authority scopes. The bridge carries no production remote-control,
deployment, update or lifecycle authority. Production control uses separate
fixed server-owned native Kodi actions; this is not an arbitrary production
command channel.

Protocol 1 advertises `screenshot` and `workspace_deployment`. Production uses
only `screenshot`. On an approved external-development target, deployment is a
closed, pathless operation for one exactly authorized copied Python video
plug-in: Kodi Lab sends an exact manifest and referenced content chunks while
the add-on derives the destination from `special://home/addons` and the
descriptor add-on ID. It provides no filesystem browsing, arbitrary
upload/install, URL install, raw JSON-RPC proxy, shell, restart, profile or host
lifecycle access.

Screenshot captures the full Kodi GUI through
`TakeScreenshot(<bridge-owned-path>,sync)`. The add-on alone creates an
unpredictable name below `special://temp/kodi-lab-bridge`, performs bounded PNG
readback and validation, and deletes the file before responding. Short-TTL
crash cleanup scans only that directory and strict bridge capture names. No
request can provide a path or use the bridge as a file reader, and image bytes,
native paths and GUI content are never written to Lab audit or logs. Kodi 22
ignores the older `sync` option, so the bridge bounds completion by retrying
only its exact generated file until a complete valid PNG appears.

The bridge stages and verifies the complete tree, preserves add-on enablement,
retains one immediate rollback copy, replaces the directory, and verifies the
final tree and Kodi inventory. Incoming Python bytecode and VCS metadata are
rejected. Installed-tree inspection omits only normal direct regular `.pyc`
children of real `__pycache__` directories because Kodi's external Python
runtime can create those after a valid invocation. That scan is non-recursive,
count/size bounded, and rejects links, nested directories and unknown files;
all source paths remain exact provenance.
Inventory verification requests only the Kodi 19.5-through-22-compatible
`enabled` and `version` detail properties; Kodi returns the add-on type as a
base field, so the bridge does not request the Kodi-20-invalid `type` property.
Authenticated inspection failures return the bounded
`addon_inspection_failed` classification rather than a replay classification.
Lab paces content at 16 MiB/s and bounds one deployment invocation to two hours.
One deployment may be active; operation metadata is capped at 64. Abandoned
staging bytes terminalize after 24 hours, while terminal and unresolved receipt
identity is retained rather than evicted for capacity.

`fixed_execution` is deliberately not a bridge capability. Kodi Lab performs
the existing fixed native video-plugin directory smoke after it has exact
bridge deployment provenance. If a replacement receipt is lost, use the Web
reconciliation action; do not reinstall, delete bridge state, or manually
repeat the deployment. A rollback-failed/replacing receipt requires operator
reconciliation before further deployment.

HTTP HMAC protects identity, integrity and replay but does not encrypt traffic.
The durable bounded replay ledger never evicts a live screenshot request
identity: when that protected capacity is exhausted the bridge rejects new
work. Read-only and content-addressed deployment messages may be evicted from
the ledger because their handlers independently reject conflicts and are
idempotent; legacy ledger entries are treated as protected until they expire.
Use a trusted network or normal certificate-validated HTTPS where required.
Kodi Lab does not automatically install or update this add-on. Follow the
canonical Kodi Lab bridge and production-validation documentation for the
detailed operating and recovery procedures.
