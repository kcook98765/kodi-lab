"""Only exact new image steps evidenced by this campaign's immutable build logs."""
from datetime import datetime
import json,re
import lab
c=lab.client();cutoff=(lab.ROOT/'private/inventory-before.json').stat().st_mtime;steps={}
for p in (lab.ROOT/'evidence').glob('build*-*.log'):
 lines=p.read_text().splitlines()
 for index,line in enumerate(lines):
  match=re.search(r'---> ([0-9a-f]{12})\b',line)
  if match and (index==0 or 'Using cache' not in lines[index-1]):steps.setdefault(match[1],[]).append(p.name)
all_images={im.id:im for im in c.images.list(all=True)};owned={};cached=[]
for iid,im in all_images.items():
 prefix=iid.removeprefix('sha256:')[:12]
 if prefix not in steps:continue
 if datetime.fromisoformat(im.attrs['Created'].replace('Z','+00:00')).timestamp()<=cutoff:cached.append(iid);continue
 assert not c.containers.list(all=True,filters={'ancestor':iid});assert not any(x['Image']==iid for x in lab.load('private/inventory-before.json'));owned[iid]=im
for iid in owned:
 children={child for child,im in all_images.items() if im.attrs.get('Parent')==iid};assert children<=set(owned),('Unowned descendant',iid,children-set(owned))
lab.save('private/owned-build-intermediates-before.json',[{'inspect':im.attrs,'build_logs':steps[iid.removeprefix('sha256:')[:12]]} for iid,im in owned.items()]);removed=[]
while owned:
 parents={im.attrs.get('Parent') for im in owned.values()};leaves=[iid for iid in owned if iid not in parents];assert leaves
 for iid in leaves:c.images.remove(iid,noprune=True);removed.append(iid);owned.pop(iid)
lab.save('evidence/cleanup-build-intermediates.json',{'removed_exact_ids':removed,'cached_steps_preserved':cached,'provenance':'Exact build-log step ID, image creation after preflight, no container reference and no unowned descendant','host_wide_prune':False});print('Removed',len(removed),'verified new build steps; preserved',len(cached),'pre-existing cached steps')
