"""Build only isolated candidate images, retaining immutable provenance."""
from pathlib import Path
import hashlib,json,os,subprocess
import docker
ROOT=Path(__file__).resolve().parents[1];SOURCE=Path('/home/kyle/kodi-lab-worktrees/novnc-phase2-20261027')
os.umask(0o077)
folder=ROOT/'private/app-build8';folder.mkdir(exist_ok=True)
subprocess.run(['uv','run','--locked','python','-m','build','--wheel','--no-isolation','--outdir',str(folder)],cwd=SOURCE,check=True,stdout=(ROOT/'evidence/build8-wheel-build.log').open('w'),stderr=subprocess.STDOUT)
wheels=list(folder.glob('*.whl'));assert len(wheels)==1;wheel=wheels[0]
source_files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=SOURCE,text=True).splitlines()
manifest={p:hashlib.sha256((SOURCE/p).read_bytes()).hexdigest() for p in source_files if (SOURCE/p).is_file()}
(ROOT/'evidence/build8-source.json').write_text(json.dumps(manifest,indent=2))
base=json.loads((ROOT.parent/'novnc-phase1-20261026/evidence/frozen-app-images.json').read_text())['images']
results={'wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'images':{},'source_manifest_sha256':hashlib.sha256((ROOT/'evidence/build8-source.json').read_bytes()).hexdigest()}
for role in ('web','broker'):
 df=folder/('Dockerfile.'+role)
 df.write_text(f'''FROM {base[role]}
USER root
COPY {wheel.name} /tmp/{wheel.name}
RUN python -m pip install --no-index --no-deps --force-reinstall /tmp/{wheel.name} && python -m pip check && rm /tmp/{wheel.name} && rm -rf /usr/local/lib/python3.12/site-packages/kodi_lab/runtime/catalog /usr/local/lib/python3.12/site-packages/kodi_lab/runtime/evidence
LABEL io.kodi-lab.novnc-phase2="20261027"
USER {'kodi-lab' if role=='web' else 'root'}
''')
 iid=folder/(role+'.iid')
 with (ROOT/f'evidence/build8-{role}.log').open('w') as out:subprocess.run(['docker','build','--pull=false','-f',str(df),'--iidfile',str(iid),str(folder)],env={**os.environ,'DOCKER_BUILDKIT':'0'},stdout=out,stderr=subprocess.STDOUT,check=True,timeout=90)
 image=iid.read_text().strip();results['images'][role]=image
 with (ROOT/'private/resources.jsonl').open('a') as f:f.write(json.dumps({'role':role+'-candidate','kind':'image','id':image})+'\n')
(ROOT/'evidence/app-images.json').write_text(json.dumps(results,indent=2))
assert all(hashlib.sha256((SOURCE/p).read_bytes()).hexdigest()==h for p,h in manifest.items())
print(json.dumps(results,indent=2))
