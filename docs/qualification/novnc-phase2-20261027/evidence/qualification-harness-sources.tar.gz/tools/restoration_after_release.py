"""Read-only post-cleanup health, exact resource and public-ingress evidence."""
import hashlib,json,time,socket,subprocess
from pathlib import Path
import lab
c=lab.client();before=lab.load('private/inventory-before.json');ids={x['Id'] for x in before};now=c.containers.list(all=True);assert {x.id for x in now}==ids
assert not c.containers.list(filters={'label':'io.kodi-lab.managed=true'})
assert not c.images.list(all=True,filters={'label':'io.kodi-lab.novnc-phase2=20261027'}) and not c.volumes.list(filters={'label':'io.kodi-lab.novnc-phase2=20261027'}) and not c.networks.list(filters={'label':'io.kodi-lab.novnc-phase2=20261027'})
processes=[lab.load('private/test-proxy.json')]+[json.loads(x) for x in (lab.ROOT/'private/event-watch-identities.jsonl').read_text().splitlines()]
for x in processes:
 p=Path('/proc')/str(x['pid'])
 try:assert p.joinpath('stat').read_text().split(') ',1)[1].split()[19]!=str(x['start'])
 except FileNotFoundError:pass
for port in (18108,18109):
 with socket.socket() as s:s.settimeout(.3);assert s.connect_ex(('127.0.0.1',port))!=0
checks={};target=lab.load('private/target.json')['target']
for path,expected in [('/login',200),('/static/live-display.js',200),('/static/novnc-phase1.js',404),('/instances/'+target+'/novnc-phase1',404),('/mcp',404)]:
 q=subprocess.run(['curl','--silent','--show-error','--insecure','--pinnedpubkey','sha256//Vzbzq9HjOHqVqA7F9K1whQhIeBVB3AEIoRbptR4WAAk=','--max-time','5','--output','/dev/null','--write-out','%{http_code}','https://192.168.2.191:8443'+path],capture_output=True,text=True,timeout=6);assert q.returncode==0 and int(q.stdout)==expected,(path,q.returncode,q.stdout);checks[path]=int(q.stdout)
web=lab.load('evidence/preflight.json')['services']['web']['id'];cid=lab.load('private/revocation-reference.json')['credential_id']
code="""import sqlite3,json
c=sqlite3.connect('file:/var/lib/kodi-lab/database/kodi-lab.db?mode=ro',uri=True);c.execute('pragma query_only=on');found=[]
for (name,) in c.execute("select name from sqlite_master where type='table' and name like '%credential%'"):
 cols=[x[1] for x in c.execute('pragma table_info('+name+')')]
 if 'id' in cols and 'revoked_at' in cols:
  for x in c.execute('select id,revoked_at from '+name+' where id=?',('CID',)):found.append({'table':name,'id':x[0],'revoked_at':x[1]})
assert len(found)==1 and found[0]['revoked_at'];print(json.dumps(found))
""".replace('CID',cid)
x=c.containers.get(web).exec_run(['python','-c',code]);assert x.exit_code==0;retired=json.loads(x.output)
# Verify bytes referenced by all previous recorded artifact manifests.
prior=lab.load('private/prior-evidence-hashes.json');manifests={}
for path in prior:
 p=Path(path)
 if p.name!='ARTIFACT-MANIFEST.json':continue
 m=json.loads(p.read_text());files=m.get('files',{});count=0
 for rel,value in files.items():
  h=value['sha256'] if isinstance(value,dict) else value
  assert hashlib.sha256((p.parent/rel).read_bytes()).hexdigest()==h,(str(p),rel);count+=1
 manifests[str(p.parent.name)]=count
lab.save('evidence/restoration-after-release.json',{'at':time.time(),'original_container_ID_set_restored':len(ids),'all_managed_Kodi_stopped':True,'all_owned_Docker_resources_absent':True,'owned_proxy_watchers_PID_start_gone':len(processes),'loopback_test_ports_closed':[18108,18109],'public_HTTPS_SPKI_pinned_statuses':checks,'original_campaign_credential_still_revoked':retired,'prior_artifact_manifest_bytes_verified':manifests,'retired_MCP_token_emptied':not (lab.ROOT/'private/mcp-token').read_text(),'retired_test_password_emptied':not (lab.ROOT/'private/admin-password').read_text()});print('Restoration audit passed; original271 container identities, pinned public health, old evidence and retired authority preserved')
