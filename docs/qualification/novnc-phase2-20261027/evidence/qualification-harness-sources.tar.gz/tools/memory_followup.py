"""Unreached memory/reconnect coverage only; retains the agent-latency FAIL."""
import os,time,traceback
os.environ['RUN_ID']='memory1-'
import lab,core as c,acceptance_support as a
from trial import Trial
trial=Trial.__new__(Trial)
try:
 assert not (lab.ROOT/'evidence/browser-memory-safety-abort.json').exists()
 assert lab.load('evidence/latency-perf2-motion-interactive-agents.json')['pass'] is False
 trial.__init__('memory1');c.movie();trial.start_view();c.wait(1.2);c.browser.call('take');a.flags(True,'memory1-interactive');c.wait(1.2)
 before=c.stage('fps-before',10,probe='frames');assert before['frames']['invalid']==0 and before['frames']['transitions']>=17 and before['frames']['max_gap_ms']<=1000
 c.stage('ordinary-motion-no-pixel-readback',100)
 after=c.stage('fps-after',10,probe='frames');assert after['frames']['invalid']==0 and after['frames']['transitions']>=17 and after['frames']['max_gap_ms']<=1000
 trial.stop_view('main');cycles=[]
 for index in range(5):
  start=trial.start_view();c.stage('cycle-'+str(index)+'-on',2);stop=trial.stop_view('cycle-'+str(index));off=c.stage('cycle-'+str(index)+'-off',3);cycles.append({'index':index,'start':start,'stop':stop,'off':off})
 lab.save('evidence/memory1-cycles.json',cycles);trial.stop_native();c.stage('native-stopped-disconnected',20);c.browser.call('closePage');c.stage('document-closed',30);trial.completed=True
except BaseException as error:
 lab.save('evidence/memory1-error.json',{'error':str(error),'traceback':traceback.format_exc()});print(traceback.format_exc(),flush=True)
finally:trial.close()
assert trial.completed
