"""Low-volume browser IPC and PID/start-time-fenced tree RSS/PSS accounting."""
import json,os,selectors,subprocess,time
from pathlib import Path
import lab

def proc(pid):
    p=Path('/proc')/str(pid);raw=(p/'stat').read_text();f=raw[raw.rfind(')')+2:].split()
    return {'pid':int(pid),'ppid':int(f[1]),'start':int(f[19]),'comm':(p/'comm').read_text().strip(),'ticks':int(f[11])+int(f[12])}

class Browser:
    def __init__(self,tag,engine='chromium'):
        self.tag=tag
        self.seq=0;self.root=None;self.samples=[]
        self.p=subprocess.Popen(['node',str(lab.ROOT/'tools/browser.cjs')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,env={**os.environ,'RUN_ID':tag,'BROWSER_ENGINE':engine},stderr=(lab.ROOT/f'evidence/browser-{self.tag}.stderr').open('w'),text=True,bufsize=1)
        self.info=self.call('open');self.root=proc(self.info['root_pid'])
        lab.save(f'evidence/browser-identity-{self.tag}.json',{'root':self.root,'version':self.info['browser'],'engine':engine,'launch':self.info,'node':proc(self.p.pid)})
    def call(self,action,**kwargs):
        self.seq+=1;self.p.stdin.write(json.dumps({'id':self.seq,'action':action,**kwargs})+'\n');self.p.stdin.flush();s=selectors.DefaultSelector();s.register(self.p.stdout,selectors.EVENT_READ)
        try:assert s.select(15),'Browser IPC absolute deadline'
        finally:s.close()
        line=self.p.stdout.readline();assert line,'Browser exited';value=json.loads(line);assert value['id']==self.seq and 'error' not in value,value.get('error');return value['result']
    def sample(self,stage,native_only=False):
        value={'processes':{'processInfo':[]}} if native_only else self.call('sample');root=proc(self.root['pid']);assert root['start']==self.root['start'],'Browser root identity changed'
        allprocs={}
        for p in Path('/proc').iterdir():
            if p.name.isdigit():
                try:allprocs[int(p.name)]=proc(int(p.name))
                except (OSError,ValueError,IndexError):pass
        owned={root['pid']};old=set()
        while old!=owned:
            old=set(owned);owned.update(pid for pid,p in allprocs.items() if p['ppid'] in owned)
        types={int(p['id']):p['type'] for p in value['processes']['processInfo']};rows=[]
        for pid in sorted(owned):
            try:
                before=proc(pid);status=(Path('/proc')/str(pid)/'status').read_text();fields={x.split(':')[0]:int(x.split()[1]) for x in status.splitlines() if x.startswith(('VmRSS:','VmHWM:','VmSwap:'))}
                try:smaps=(Path('/proc')/str(pid)/'smaps_rollup').read_text();access='owner'
                except PermissionError:
                    q=subprocess.run(['sudo','-n','cat','/proc/'+str(pid)+'/smaps_rollup'],capture_output=True,text=True,timeout=1);assert q.returncode==0,'PSS not readable';smaps=q.stdout;access='read-only sudo'
                m={x.split(':')[0]:int(x.split()[1]) for x in smaps.splitlines() if ':' in x and x.split(':')[0] in ('Rss','Pss','Private_Clean','Private_Dirty','Swap','SwapPss')}
                after=proc(pid);assert after['start']==before['start']==allprocs[pid]['start']
                rows.append({**before,'type':types.get(pid,'other browser descendant'),'rss_status_kib':fields.get('VmRSS',0),'hwm_kib':fields.get('VmHWM',0),'rss_smaps_kib':m['Rss'],'pss_kib':m['Pss'],'uss_kib':m.get('Private_Clean',0)+m.get('Private_Dirty',0),'swap_kib':m.get('Swap',0),'access':access})
            except (FileNotFoundError,ProcessLookupError):pass
        expected=set(types);covered={p['pid'] for p in rows};assert expected<=covered,('Missing live CDP process from tree',expected-covered)
        value.update(browser_run=self.tag,stage=stage,host_at=time.time()*1000,tree=rows,tree_rss_status_mib=sum(p['rss_status_kib'] for p in rows)/1024,tree_rss_smaps_mib=sum(p['rss_smaps_kib'] for p in rows)/1024,tree_pss_mib=sum(p['pss_kib'] for p in rows)/1024,tree_uss_mib=sum(p['uss_kib'] for p in rows)/1024,cdp_rss_status_mib=sum(p['rss_status_kib'] for p in rows if p['pid'] in expected)/1024)
        self.samples.append(value)
        with (lab.ROOT/('evidence/browser-memory-continuous.jsonl' if native_only else 'evidence/browser-memory.jsonl')).open('a') as f:f.write(json.dumps(value)+'\n');f.flush();os.fsync(f.fileno())
        return value
    def close(self):
        try:self.call('close');self.p.stdin.close()
        except Exception:self.p.terminate()
        try:self.p.wait(timeout=3)
        except subprocess.TimeoutExpired:self.p.kill();self.p.wait(timeout=2)
        deadline=time.monotonic()+3
        while time.monotonic()<deadline:
            try:
                if proc(self.root['pid'])['start']!=self.root['start']:break
            except (FileNotFoundError,ProcessLookupError):break
            time.sleep(.05)
        else:raise RuntimeError('Browser process remains after close')
        lab.save(f'evidence/browser-closed-{self.tag}.json',{'root_pid':self.root['pid'],'root_start':self.root['start'],'root_gone':True,'node_exit':self.p.returncode})
