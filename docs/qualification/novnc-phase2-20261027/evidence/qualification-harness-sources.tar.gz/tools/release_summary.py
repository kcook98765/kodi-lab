"""Preserve original failed stages and focused followups without relabeling them."""
import json,re,xml.etree.ElementTree as ET
from pathlib import Path
r=Path(__file__).resolve().parents[1];e=r/'evidence';attempts=[]
for name in ['release.log','release-resume.log','release-contract-resume.log','release-post-tests.log']:
 p=e/name
 if not p.exists():continue
 text=p.read_text();match=re.search(r'^check evidence: (.+)$',text,re.M)
 stages=[]
 if match:
  folder=Path(match[1]);f=folder/'stages.tsv'
  if f.exists():
   for line in f.read_text().splitlines():
    stage,seconds,status=line.split('\t');stages.append({'stage':stage,'seconds':int(seconds),'exit_status':int(status)})
 attempts.append({'log':name,'evidence_directory':Path(match[1]).name if match else None,'stages':stages})
folder=e/'kodi-lab-check-results.2pQFGpZb';tree=ET.parse(folder/'pytest.xml');cases=tree.findall('.//testcase');failed=[];skipped=[]
for case in cases:
 for tag,dest in [('failure',failed),('error',failed),('skipped',skipped)]:
  child=case.find(tag)
  if child is not None:dest.append({'class':case.get('classname'),'name':case.get('name'),'reason':child.get('message',''),'kind':tag})
out={'full_suite_candidate':'ead3b71d8269ecbb36ece4e29eee4a5bd0c347fd','full_suite_runs':1,'full_suite_collected':len(cases),'full_suite_passed':len(cases)-len(failed)-len(skipped),'full_suite_failed_or_errors':failed,'full_suite_skipped':skipped,'attempts':attempts,'original_failures_preserved':True,'whole_tree_mypy_pass_files':787,'standalone_mirror_mypy_pass_files':4,'full_suite_NOT_rerun':True}
for name in ['focused-schema-contract-followup.log','focused-migration-tables-followup.log']:
 p=e/name
 if p.exists():
  text=p.read_text();out[name]={'focused_pass':'FOCUSED PASS'in text,'passed_counts':[int(x) for x in re.findall(r'(\d+) passed',text)]}
(e/'release-summary.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['attempts','full_suite_skipped','full_suite_failed_or_errors']},indent=2))
