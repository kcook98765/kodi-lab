"""Reduce only this isolated human session's expiry; no authorization bypass."""
import hashlib,json,time
import httpx
import lab,core as c,acceptance_support as a
def run():
 c.browser.call('start');c.browser.call('take');cookies=c.browser.call('cookies');token=next(x['value']['value'] for x in cookies['cookies'] if x['name']=='kodi_lab_session');digest=hashlib.sha256(token.encode()).hexdigest();before=a.ownership();began=time.time()
 code="""from datetime import datetime,UTC,timedelta
from sqlalchemy import update
from kodi_lab.config import Settings
from kodi_lab.storage.engine import create_database_engine,create_session_factory
from kodi_lab.storage.models import WebSessionRow
f=create_session_factory(create_database_engine(Settings(_env_file=None).database_url))
with f.begin() as s:
 q=s.execute(update(WebSessionRow).where(WebSessionRow.token_digest=='DIGEST').values(absolute_expires_at=(datetime.now(UTC)-timedelta(seconds=1)).strftime('%Y-%m-%dT%H:%M:%S.%fZ')));assert q.rowcount==1
print('One isolated qualification session expired')
""".replace('DIGEST',digest)
 web=lab.client().containers.get(lab.load('private/services.json')['web']['id']);q=web.exec_run(['python','-c',code]);assert q.exit_code==0;c.wait(3);clean=a.clean('jpeg1-auth-expiry');status=c.browser.call('status');assert status['status']=='Off' or status['status'].startswith('Stopping.')
 with httpx.Client(trust_env=False,timeout=3) as h:q=h.get(a.BASE+'/api/instances/'+lab.load('private/target.json')['target'],cookies={'kodi_lab_session':token})
 assert q.status_code==401;r,ms,_=a.remote('left');assert not r.get('isError');lab.save('evidence/native-auth-session-expiry.json',{'fixture':'Reduced absolute_expires_at for exactly the logged-in disposable Firefox Web session; no production session or authorization bypass.','ownership_before':before,'cleanup':clean,'status':status,'cookie_reuse_HTTP':q.status_code,'agent_resumed_ms':ms,'observation_seconds':time.time()-began});c.browser.call('login');c.browser.call('page')
