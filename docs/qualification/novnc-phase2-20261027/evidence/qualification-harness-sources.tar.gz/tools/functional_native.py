"""Actual Firefox input on the authenticated human Web path, simulation labeled."""
import os,time,json,traceback
os.environ['RUN_ID']='functional1-'
import lab,core as c,acceptance_support as a
from trial import Trial
trial=Trial.__new__(Trial);receipts={}
def call(action,**kw):
 c.mon.check();value=c.browser.call(action,**kw);c.wait(.18);return value

def save(name,value):receipts[name]=value;lab.save('evidence/functional-'+name+'.json',value)
try:
 trial.__init__('functional1')
 c.home();lab.rpc('Input.Left');lab.rpc('Input.ExecuteAction',{'action':'firstpage'});c.wait(.3)
 calibration=[]
 for action in ['Input.Right','Input.Left','Input.Right','Input.Left']:
  _,timing=lab.rpc(action);c.wait(.3);calibration.append({'action':action,'state':c.source.rows[-1]['menu'],**timing})
 c.menu_expected={v['action']:v['state'] for v in calibration[-2:]};save('calibration',calibration)
 trial.start_view();a.flags(False,'functional-vo');c.stage('view-only-static',5)
 # Deliberately defeat only the client-side convenience flag. The native server
 # must still refuse real Firefox keyboard/pointer input in view-only mode.
 before=a.xstate();before_ui=a.ui();call('evaluate',expression="(()=>{phase1Rfb.viewOnly=false;phase1Rfb.focus();return true})()")
 call('key',value='a',hold=True);call('move',x=410,y=300);held=a.xstate();call('key',value='a',up=True)
 call('evaluate',expression="(()=>{phase1Rfb.viewOnly=true;return true})()")
 assert held['keys']==before['keys'] and held['root_xy']==before['root_xy'] and a.ui()==before_ui
 save('server-view-only-denial',{'before':before,'attempted':held,'ui_unchanged':True,'client_flag_only_overridden_for_negative_test':True})
 permitted,_,_=a.remote('right');assert not permitted.get('isError');permitted,_,_=a.remote('left');assert not permitted.get('isError')
 old=a.ownership()[0];take=call('take');new=a.ownership()[0];assert old['attempt']!=new['attempt'] and old['absolute_expires_at']==new['absolute_expires_at'];save('take-control',{'ui':take,'old':old,'new':new});a.flags(True,'functional-interactive')
 blocked,ms,_=a.remote('right');assert blocked.get('isError');save('agent-refused',{'response':blocked,'ms':ms})
 target=lab.load('private/target.json')['target'];web=a.web_post('/api/instances/'+target+'/remote-actions',{'action':'right'});assert web.status_code==409;start=a.web_post('/api/instances/'+target+'/start',{});assert start.status_code==409;save('web-conflicts',{'remote_status':web.status_code,'start_status':start.status_code})
 inspected,ms,_=a.mcp_raw('inspect_ui_state',{'target_id':target});assert not inspected.get('isError');save('readonly-inspection',{'isError':False,'ms':ms})
 a.screenshot('functional-controller')
 image,ms,_=a.mcp_raw('screenshot_capture',{'target_id':target});assert not image.get('isError');save('readonly-mcp-screenshot',{'isError':False,'ms':ms,'content_types':[x['type'] for x in image.get('content',[])]})
 call('probe',scene='menu');actions=[]
 for i in range(8):
  value='ArrowRight' if i%2==0 else 'ArrowLeft';sent=call('key',value=value);actions.append({'key':value,'sent':sent['sent'],'expected':c.menu_expected['Input.Right' if i%2==0 else 'Input.Left']});c.wait(.65)
 shown=call('endProbe');matches=[]
 for action in actions:
  native=next((r for r in c.source.rows if action['sent']<=r['at']<action['sent']+1200 and r['menu']==action['expected']),None)
  display=next((r for r in shown['menus'] if action['sent']<=r['at']<action['sent']+1200 and r['state']==action['expected']),None)
  matches.append({**action,'native_ms':native['at']-action['sent'] if native else None,'display_ms':display['at']-action['sent'] if display else None})
 save('menu-responsiveness',{'matches':matches,'display_latency':c.dist([r['display_ms'] for r in matches if r['display_ms'] is not None]),'all_displayed':all(r['display_ms'] is not None for r in matches)})
 keys=[]
 for key in ['ArrowDown','ArrowUp','Enter','Escape','Backspace']:
  before=a.ui();timing=call('key',value=key);c.wait(.45);keys.append({'key':key,'before':before,'after':a.ui(),**timing})
 save('kodi-key-mappings',keys)
 # Pointer/wheel/drag originate in Firefox input.performActions, not DOM mocks.
 call('move',x=410,y=285);moved=a.xstate();assert moved['root_xy']==[410,285]
 call('down',x=410,y=285);pressed=a.xstate();assert pressed['mask']&256
 call('up',x=410,y=285);released=a.xstate();assert not released['mask']&0x1f00
 dragged=call('drag',x=400,y=270);after_drag=a.xstate();assert after_drag['root_xy']==[470,310] and not after_drag['mask']&0x1f00
 wheel=call('wheel',delta=120);save('pointer-wheel-drag',{'moved':moved,'pressed':pressed,'released':released,'drag':dragged,'after_drag':after_drag,'wheel':wheel,'physical_touchpad_acceptance':False})
 try:touch=call('touch',x=400,y=250);touch={'simulated':True,'command':touch,'native':a.xstate(),'physical_touchscreen_acceptance':False}
 except Exception as error:touch={'simulated':True,'supported':False,'error':str(error),'physical_touchscreen_acceptance':False}
 save('touch-simulation',touch)
 fullscreen=call('expand');save('fullscreen',fullscreen);call('expand')
 # Release with keys/button deliberately held: only verified native cleanup may
 # allow existing input to resume. No client key-up is needed for server proof.
 call('focusCanvas');call('key',value='a',hold=True);call('down',x=410,y=285);held=a.xstate();assert held['keys'] and held['mask']&256
 release=call('release');neutral=a.xstate();assert not neutral['keys'] and not neutral['mask']&0x1f00
 # Clear the WebDriver device state after the server has already proven neutral.
 call('key',value='a',up=True);call('up',x=410,y=285);resumed,ms,_=a.remote('left');assert not resumed.get('isError');save('held-input-release',{'held':held,'release':release,'neutral_before_client_keyup':neutral,'agent_resumed_ms':ms})
 trial.stop_view('functional-end');c.stage('disconnected',5);trial.completed=True
except BaseException as error:
 lab.save('evidence/functional1-error.json',{'error':str(error),'traceback':traceback.format_exc()});print(traceback.format_exc(),flush=True)
finally:trial.close()
assert trial.completed
