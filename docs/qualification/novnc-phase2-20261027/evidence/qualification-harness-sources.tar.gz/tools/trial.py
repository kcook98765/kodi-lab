"""One bounded Firefox human-Web qualification trial; exact native cleanup."""
import os,json,time,subprocess,traceback,hashlib
from pathlib import Path
import lab,core as c
from browser_memory import Browser
from browser_guard import BrowserGuard
from drivers import Source
import acceptance_support as a
class Trial:
 def __init__(self,tag,source=True):
  self.tag=tag;self.guard=None;self.completed=False;os.environ['RUN_ID']=tag+'-'
  if (lab.ROOT/'evidence/active-budget.json').exists():c.mon.used=lab.load('evidence/active-budget.json')['monitor_cumulative_seconds']
  if (lab.ROOT/'evidence/stages.json').exists():c.results=lab.load('evidence/stages.json')
  c.mon.start();c.browser=Browser(tag,'firefox');self.guard=BrowserGuard(c.browser,c.mon)
  baseline=c.stage('blank',15);self.guard.baseline=c.browser_baseline=baseline['tree_rss_smaps_mib']['median']
  self.start_native(source)
 def ledger(self,event):
  n=lab.fence()
  with (lab.ROOT/'evidence/native-active-ledger.jsonl').open('a') as f:f.write(json.dumps({'event':event,'tag':self.tag,'at':time.time(),'container':n.id,'state':n.attrs['State']})+'\n');f.flush();os.fsync(f.fileno())
 def start_native(self,source):
  previous=lab.load('private/event-watch.json') if (lab.ROOT/'private/event-watch.json').exists() else None
  if previous:
   p=Path('/proc')/str(previous['pid'])
   try:alive=p.joinpath('stat').read_text().split(') ',1)[1].split()[19]==previous['start'] and str(lab.ROOT/'tools/watch_execs.py').encode() in p.joinpath('cmdline').read_bytes()
   except FileNotFoundError:alive=False
  else:alive=False
  if not alive:
   subprocess.Popen([lab.PY,str(lab.ROOT/'tools/watch_execs.py')],stdout=(lab.ROOT/('evidence/event-watch-'+self.tag+'.log')).open('w'),stderr=subprocess.STDOUT)
   c.wait(.2)
  lab.save('private/operator-session-before-default-'+self.tag+'.json',lab.load('private/operator-session.json'))
  lab.start_stack(self.tag+'-default');lab.ready();lab.login()
  lab.mutate('start','start-'+self.tag);self.ledger('start');deadline=time.monotonic()+30
  while time.monotonic()<deadline:
   c.mon.check();n=lab.fence()
   if n.attrs['State'].get('Health',{}).get('Status')=='healthy' and lab.status()['usability_state']=='usable':break
   c.wait(.25)
  else:raise RuntimeError('Native readiness deadline')
  from retire_fault_socket import run as retire_fault_socket;retire_fault_socket()
  a.screenshot(self.tag+'-viewer-disabled')
  import httpx
  with httpx.Client(trust_env=False,timeout=3) as h:
   s=lab.load('private/operator-session.json');q=h.get(f'http://127.0.0.1:{lab.PORT}/instances/'+lab.load('private/native.json')['target']+'/novnc-phase1',cookies={'kodi_lab_session':s['token']});assert q.status_code==404
  lab.save('evidence/independent-default-capture-'+self.tag+'.json',{'viewer_page_status':q.status_code,'existing_X11_capture_passed':True})
  lab.save('private/operator-session-before-'+self.tag+'.json',lab.load('private/operator-session.json'));lab.start_stack(self.tag,lab.pin());lab.ready();lab.login()
  deadline=time.monotonic()+30
  while time.monotonic()<deadline:
   if lab.status()['usability_state']=='usable':break
   c.wait(.25)
  else:raise RuntimeError('Replacement Web readiness')
  if source:
   c.source=Source(lab.fence());assert (c.source.info['width'],c.source.info['height'])==(640,360)
  proof=a.native_code(r'''import json
from pathlib import Path
rows=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  name=p.joinpath('comm').read_text().strip()
  if name=='kodi.bin':
   env=dict(x.split(b'=',1) for x in p.joinpath('environ').read_bytes().split(b'\0') if b'=' in x)
   rows.append({'name':name,'pid':int(p.name),'LP_NUM_THREADS':env.get(b'LP_NUM_THREADS',b'').decode(),'workers':[t.joinpath('comm').read_text().strip() for t in p.joinpath('task').iterdir() if t.joinpath('comm').read_text().startswith('llvmpipe-')]})
  elif name=='Xvfb':rows.append({'name':name,'pid':int(p.name),'args':[x.decode() for x in p.joinpath('cmdline').read_bytes().split(b'\0') if x]})
 except FileNotFoundError:pass
print(json.dumps(rows))
''');k=next(x for x in proof if x['name']=='kodi.bin');assert k['LP_NUM_THREADS']=='1' and len(k['workers'])==1;assert '640x360x24' in next(x for x in proof if x['name']=='Xvfb')['args'];lab.save('evidence/native-proof-'+self.tag+'.json',proof)
  q=lab.fence().exec_run(['dpkg-query','-W','-f=${Package}\t${Version}\n','kodi','kodi-bin','libgl1-mesa-dri','libllvm21','tigervnc-scraping-server','xvfb'],user='1000:1000');assert q.exit_code==0;(lab.ROOT/f'evidence/packages-{self.tag}.txt').write_bytes(q.output)
  lab.save('evidence/browser-page-'+self.tag+'.json',c.browser.call('page'));c.stage('inactive',5)
  import httpx
  with httpx.Client(trust_env=False,verify=str(lab.ROOT/'private/tls/ca.crt'),timeout=3) as h:
   source_root=Path('/home/kyle/kodi-lab-worktrees/novnc-phase2-20261027/src/kodi_lab/web/static/vendor/novnc');served=[]
   for file in ['core/rfb.js','core/display.js','core/decoders/tight.js']:
    q=h.get('https://localhost:18109/static/vendor/novnc/'+file);q.raise_for_status();assert q.content==(source_root/file).read_bytes();served.append({'file':file,'sha256':hashlib.sha256(q.content).hexdigest()})
  lab.save('evidence/served-noVNC-'+self.tag+'.json',served)
 def start_view(self):
  result=c.browser.call('start');lab.save('evidence/view-start-'+self.tag+'-'+str(time.time_ns())+'.json',result);return result
 def stop_view(self,tag):
  result=c.browser.call('stop');clean=a.clean(self.tag+'-'+tag);return {'ui':result,'native':clean}
 def stop_native(self):
  if lab.fence().attrs['State']['Running']:
   c.mon.stop_native('stop-'+self.tag);self.ledger('stop')
 def close(self):
  try:
   if self.guard:self.guard.close()
  except Exception as error:lab.save('evidence/guard-close-'+self.tag+'.json',{'error':str(error)})
  try:
   if c.browser:c.browser.close()
  except Exception as error:lab.save('evidence/browser-close-'+self.tag+'.json',{'error':str(error)})
  try:self.stop_native()
  except Exception as error:lab.save('evidence/native-stop-'+self.tag+'.json',{'error':str(error)})
  if c.source:
   try:c.source.finish(self.tag)
   except Exception as error:lab.save('evidence/source-close-'+self.tag+'.json',{'error':str(error)})
  n=lab.fence();(lab.ROOT/f'private/native-{self.tag}-logs.txt').write_bytes(n.logs());lab.save('private/native-'+self.tag+'-stopped.json',n.attrs)
  c.mon.close();lab.save('evidence/active-budget.json',{'monitor_cumulative_seconds':c.mon.used});lab.save('evidence/result-'+self.tag+'.json',{'completed':self.completed,'native_stopped':not n.attrs['State']['Running'],'native_accounted_seconds':c.mon.used,'safety_abort':c.mon.abort.is_set(),'reason':c.mon.reason});print('Trial',self.tag,'complete',self.completed,flush=True)
