from pathlib import Path
import json,os,subprocess,time
ROOT=Path(__file__).resolve().parents[1];p=ROOT/'private/tls';p.mkdir(exist_ok=True,mode=0o700)
os.umask(0o077)
def run(args):
 with (ROOT/'evidence/tls-preparation.log').open('a') as out:subprocess.run(args,stdout=out,stderr=subprocess.STDOUT,check=True,timeout=10)
if not (p/'ca.crt').exists():
 run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-days','2','-subj','/CN=Kodi Lab Phase2 Disposable CA','-keyout',str(p/'ca.key'),'-out',str(p/'ca.crt')])
 run(['openssl','req','-new','-newkey','rsa:2048','-nodes','-subj','/CN=localhost','-keyout',str(p/'server.key'),'-out',str(p/'server.csr')])
 (p/'extensions').write_text('subjectAltName=DNS:localhost,IP:127.0.0.1\nbasicConstraints=critical,CA:FALSE\nkeyUsage=critical,digitalSignature,keyEncipherment\nextendedKeyUsage=serverAuth\n')
 run(['openssl','x509','-req','-in',str(p/'server.csr'),'-CA',str(p/'ca.crt'),'-CAkey',str(p/'ca.key'),'-CAcreateserial','-days','2','-extfile',str(p/'extensions'),'-out',str(p/'server.crt')])
config=p/'nginx.conf';config.write_text(f'''pid {p}/nginx.pid;
error_log {ROOT}/evidence/test-proxy-error.log warn;
worker_processes 1;
events {{ worker_connections 64; }}
http {{
 access_log off;
 client_body_temp_path {p}/body;
 proxy_temp_path {p}/proxy;
 server {{
  listen 127.0.0.1:18109 ssl;
  server_name localhost;
  ssl_certificate {p}/server.crt;
  ssl_certificate_key {p}/server.key;
  ssl_protocols TLSv1.2 TLSv1.3;
  location / {{
   proxy_pass http://127.0.0.1:18108;
   proxy_http_version 1.1;
   proxy_set_header Host $http_host;
   proxy_set_header X-Forwarded-Proto https;
   proxy_set_header X-Forwarded-For $remote_addr;
   proxy_set_header Upgrade $http_upgrade;
   proxy_set_header Connection "upgrade";
   proxy_read_timeout 620s;
   proxy_buffering off;
  }}
 }}
}}
''')
run(['nginx','-t','-c',str(config),'-p',str(p)])
child=subprocess.Popen(['nginx','-c',str(config),'-p',str(p),'-g','daemon off;'],stdout=(ROOT/'evidence/test-proxy-stdout.log').open('w'),stderr=subprocess.STDOUT)
time.sleep(.2);assert child.poll() is None
raw=Path('/proc')/str(child.pid)/'stat';f=raw.read_text();fields=f[f.rfind(')')+2:].split();(ROOT/'private/test-proxy.json').write_text(json.dumps({'pid':child.pid,'start':fields[19],'config':str(config),'origin':'https://localhost:18109','loopback_only':True,'production_ingress_modified':False}))
print('Disposable loopback TLS proxy ready; production ingress unchanged')
