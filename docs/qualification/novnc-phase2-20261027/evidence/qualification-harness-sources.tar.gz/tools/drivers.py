"""Sequential, bounded diagnosis; stop immediately at the unchanged safety gate."""
import json,os,selectors,subprocess,threading,time,math,traceback
from pathlib import Path
import lab
from monitor import Monitor
os.umask(0o077)
class Source:
    def __init__(self,n):
        self.rows=[];self.journal=(lab.ROOT/('evidence/source-stream-'+str(time.time_ns())+'.jsonl')).open('x');self.ready=threading.Event();self.done=threading.Event();self.error=None;self.api=lab.client().api
        code=(lab.ROOT/'tools/source_sampler.py').read_text();self.id=self.api.exec_create(n.id,['/usr/bin/python3','-I','-B','-u','-c',code],user='1000:1000',stdout=True,stderr=True,tty=False)['Id'];lab.record('source-observer','exec',self.id)
        self.stream=self.api.exec_start(self.id,stream=True,demux=True);self.thread=threading.Thread(target=self.read,daemon=True);self.thread.start();assert self.ready.wait(3),'Source observer readiness'
    def read(self):
        buffer=bytearray()
        try:
            for out,err in self.stream:
                if err:self.error=err.decode(errors='replace')[:500]
                if out:
                    buffer.extend(out);assert len(buffer)<65536
                    while b'\n' in buffer:
                        line,_,tail=buffer.partition(b'\n');buffer=bytearray(tail);v=json.loads(line);self.journal.write(json.dumps(v)+'\n');self.journal.flush();os.fsync(self.journal.fileno())
                        if v.get('ready'):self.info=v;self.ready.set()
                        else:self.rows.append(v)
        except Exception as e:self.error=repr(e)
        finally:self.journal.close();self.done.set()
    def stop_observer(self):
        code="import os,signal;from pathlib import Path;p=Path('/proc/PID');assert p.joinpath('stat').read_text().split(') ',1)[1].split()[19]=='START';assert b'Read-only X11 wire ROI observer' in p.joinpath('cmdline').read_bytes();os.kill(PID,signal.SIGTERM)".replace('PID',str(self.info['pid'])).replace('START',self.info['start_ticks'])
        q=lab.fence().exec_run(['/usr/bin/python3','-I','-c',code],user='1000:1000');assert q.exit_code==0;self.thread.join(3);assert self.done.is_set()
    def finish(self,tag):
        self.thread.join(3);state=self.api.exec_inspect(self.id);lab.save(f'evidence/source-{tag}.json',{'exec':self.id,'info':self.info,'rows':self.rows,'stderr':self.error,'final_exec':{'running':state['Running'],'exit_code':state.get('ExitCode')}});assert not state['Running']
def dist(v):
    v=sorted(v);return {'n':len(v),'p50':v[math.ceil(len(v)*.5)-1] if v else None,'p95':v[math.ceil(len(v)*.95)-1] if v else None,'max':max(v) if v else None}
