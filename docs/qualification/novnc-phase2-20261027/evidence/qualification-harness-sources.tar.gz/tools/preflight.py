import hashlib
import json
import os
from pathlib import Path
import subprocess

os.umask(0o077)
ROOT = Path(__file__).resolve().parents[1]
OLD = ROOT.parent / 'autonomous-campaign3-20261026'
def run(*args):
    return subprocess.check_output(args, text=True)
ids = run('docker', 'ps', '-aq', '--no-trunc').split()
inventory = json.loads(run('docker', 'inspect', *ids))
(ROOT/'private/inventory-before.json').write_text(json.dumps(inventory, indent=2))
services = {c['Config']['Labels'].get('com.docker.compose.service'): c for c in inventory if c['Config']['Labels'].get('com.docker.compose.project') == 'kodi-lab-remote'}
assert set(services) == {'web','broker','repository'}
for c in services.values():
    assert c['State']['Health']['Status'] == 'healthy'
    assert c['RestartCount'] == 0
    assert c['Config']['Labels']['io.kodi-lab.source-commit'] == '775904bd73d0ddd0ad19482db4d59e90c0c55b8e'
    assert c['HostConfig']['ReadonlyRootfs'] and not c['HostConfig']['Privileged']
    if c is not services['broker']:
        assert not any(m['Destination']=='/var/run/docker.sock' for m in c['Mounts'])
old = json.loads((OLD/'private/checkpoint-controlled-stop-final.json').read_text())
tables = ['agent_workspaces','managed_diagnostic_captures','development_sessions','development_session_policy']
probe = '''import json,sqlite3
c=sqlite3.connect('file:/var/lib/kodi-lab/database/kodi-lab.db?mode=ro',uri=True); c.row_factory=sqlite3.Row
c.execute('pragma query_only=ON');c.execute('BEGIN')
assert c.execute('pragma integrity_check').fetchone()[0]=='ok'
assert not c.execute('pragma foreign_key_check').fetchall()
r={'schema':c.execute('select version_num from alembic_version').fetchone()[0]}
'''
probe += '\n'.join('r[%r]=[dict(x) for x in c.execute(%r)]' % (t,'select * from '+t) for t in tables)
probe += '\n'+(OLD/'tools/operation_idle.py').read_text()+'\nr["idle"]=snapshot_idle(c)\nprint(json.dumps(r))'
db = json.loads(run('docker','exec',services['web']['Id'],'python','-c',probe))
assert db['schema']=='0086_addon_settings'
assert not db['idle']['blockers'] and len(db['idle']['checked_tables'])==42
for t in tables:
    assert db[t]==old['database'][t], t
assert db['agent_workspaces'][0]['generation']==18
assert len(db['managed_diagnostic_captures'])==16
native = next(c for c in inventory if c['Id']==old['containers'][0]['Id'])
assert not native['State']['Running']
assert not [c for c in inventory if c['State']['Running'] and c['Config']['Labels'].get('io.kodi-lab.managed')]
for n in [18,54,96]:
    issue = run('gh','issue','view',str(n),'--repo','kcook98765/kodi-lab','--json','number,title,state,body,comments')
    (ROOT/f'evidence/issue-{n}.json').write_text(issue)
(ROOT/'private/database-before.json').write_text(json.dumps(db,indent=2))
retired = json.loads((OLD/'evidence/campaign3-authority-retired.json').read_text())
(ROOT/'private/revocation-reference.json').write_text(json.dumps(retired))
summary={'source':'775904bd73d0ddd0ad19482db4d59e90c0c55b8e','services':{n:{'id':c['Id'],'image':c['Image'],'health':c['State']['Health']['Status']} for n,c in services.items()},'schema':db['schema'],'idle_tables':42,'workspace_generation':18,'captures':16,'nexus_stopped':native['Id'],'containers':len(inventory),'campaign_authority_retired_reference':retired.get('complete')}
(ROOT/'evidence/preflight.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
