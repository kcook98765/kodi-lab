"""Continuous1Hz PID-fenced browser memory guard independent of browser IPC."""
import threading,time,traceback
import lab
class BrowserGuard:
 def __init__(self,browser,monitor):
  self.browser=browser;self.monitor=monitor;self.baseline=None;self.done=threading.Event();self.rows=[];self.error=None;self.thread=threading.Thread(target=self.run,daemon=True);self.thread.start()
 def run(self):
  scheduled=time.monotonic()
  try:
   while not self.done.is_set():
    r=self.browser.sample('continuous-'+self.monitor.stage,native_only=True);self.rows.append(r)
    if self.baseline is not None and r['tree_rss_smaps_mib']-self.baseline>256:
     lab.save('evidence/browser-memory-safety-abort.json',{'baseline_mib':self.baseline,'sample':r,'allowance_mib':256});raise RuntimeError('Peak incremental browser RSS exceeded256MiB')
    scheduled+=1;self.done.wait(max(0,scheduled-time.monotonic()))
  except BaseException as error:
   self.error=str(error);self.monitor.reason=self.error;self.monitor.abort.set();lab.save('evidence/browser-guard-error-'+self.browser.tag+'.json',{'error':str(error),'traceback':traceback.format_exc()});self.monitor.emergency_stop()
 def close(self):
  self.done.set();self.thread.join(4);assert not self.thread.is_alive()
  lab.save('evidence/browser-guard-'+self.browser.tag+'.json',{'samples':len(self.rows),'baseline_rss_mib':self.baseline,'peak_rss_mib':max([r['tree_rss_smaps_mib'] for r in self.rows],default=0),'peak_pss_mib':max([r['tree_pss_mib'] for r in self.rows],default=0),'error':self.error})
