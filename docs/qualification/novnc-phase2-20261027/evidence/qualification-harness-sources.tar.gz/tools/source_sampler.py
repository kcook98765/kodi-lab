"""Read-only X11 wire ROI observer. No keyboard, pointer or clipboard requests."""
import socket,struct,sys,time,json,signal,os
from pathlib import Path
signal.alarm(1800)
def exact(s,n):
    b=bytearray()
    while len(b)<n:
        chunk=s.recv(n-len(b))
        if not chunk:raise EOFError()
        b.extend(chunk)
    return bytes(b)
s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);s.settimeout(1);s.connect('/tmp/.X11-unix/X99');s.sendall(struct.pack('<BBHHHHH',ord('l'),0,11,0,0,0,0));head=exact(s,8);status,_,_,_,words=struct.unpack('<BBHHH',head);b=exact(s,words*4);assert status==1
vl=struct.unpack_from('<H',b,16)[0];fc=b[21];offset=32+((vl+3)&~3)+fc*8;root=struct.unpack_from('<I',b,offset)[0];width,height=struct.unpack_from('<HH',b,offset+20);depth=b[offset+38];order=b[22];assert (width,height) in ((854,480),(640,360)) and depth==24 and order in (0,1)
formats=32+((vl+3)&~3);assert any(b[formats+i*8]==24 and b[formats+i*8+1]==32 and b[formats+i*8+2]==32 for i in range(fc));scale=width/1280
mapping_total=0
def roi(x,y,w,h):
    global mapping_total
    s.sendall(struct.pack('<BBHIhhHHI',73,2,5,root,x,y,w,h,0xffffffff));reply=exact(s,32);mapping_events=0
    while reply[0]==34:
        mapping_events+=1;mapping_total+=1;assert mapping_events<=16;reply=exact(s,32)
    assert reply[0]==1;length=struct.unpack_from('<I',reply,4)[0];data=exact(s,length*4);assert len(data)==w*h*4;return data
def rgb(data,w,x,y):
    at=(y*w+x)*4;value=int.from_bytes(data[at:at+4],'little' if order==0 else 'big');return [(value>>16)&255,(value>>8)&255,value&255]
print(json.dumps({'ready':True,'width':width,'height':height,'at':time.time()*1000,'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().split(') ',1)[1].split()[19]}),flush=True)
began=time.monotonic();lastid=None;lastmenu=None
for i in range(36000):
    before=time.time()*1000;rw=max(1,round(416*scale));rh=max(1,round(96*scale));data=roi(0,0,rw,rh)
    bit=lambda x,y:sum(rgb(data,rw,min(rw-1,int(x*scale)),min(rh-1,int(y*scale))))>384
    valid=bit(3,3);frame=0
    for j in range(12):
        v=bit(24+j*32,24);valid=valid and bit(24+j*32,56)!=v;frame+=int(v)*2**j
    greens=[]
    for x,y in ((544,425),(776,425),(200,180),(200,245)):
        patch=roi(round(x*scale),round(y*scale),2,2);greens.append(sum(rgb(patch,2,px,py)[1] for py in range(2) for px in range(2))/4)
    menu=1 if greens[0]>75 and greens[0]>greens[1]+20 else (2 if greens[1]>75 and greens[1]>greens[0]+20 else (3 if greens[2]>75 and greens[2]>greens[3]+20 else (4 if greens[3]>75 and greens[3]>greens[2]+20 else 0)))
    out={'at':time.time()*1000,'read_started':before,'valid':bool(valid),'frame':frame if valid else None,'menu':menu,'greens':greens,'mapping_notifications':mapping_total,'rfb_sockets':len(list(Path('/run/kodi').glob('view-*/rfb.sock')))}
    print(json.dumps(out),flush=True)
    time.sleep(max(0,began+(i+1)*.05-time.monotonic()))
