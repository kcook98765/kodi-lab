"""Isolated real Firefox auth/lifecycle faults. Every pause has unconditional recovery."""
import os,time,traceback,json
from uuid import uuid4
import httpx
os.environ['RUN_ID']='faults2-'
import lab,core as c,acceptance_support as a
from trial import Trial
trial=Trial.__new__(Trial)
def call(action,**kw):return c.browser.call(action,**kw)
def ev(expression):return call('evaluate',expression=expression)
def resumed(tag):
 x=a.clean(tag);assert not x['xstate']['keys'] and not x['xstate']['mask']&0x1f00
 r,ms,_=a.remote('left');assert not r.get('isError'),r;return {'cleanup':x,'agent_ms':ms}
def restart_view():call('page');trial.start_view();call('take');a.flags(True,'faults2-'+str(time.time_ns()))
try:
 trial.__init__('faults2',source=False);c.home();trial.start_view();call('take');row=a.ownership()[0]
 # A second authenticated admin still cannot own or release this tab's controller.
 target=lab.load('private/target.json')['target'];base=a.BASE;s=lab.load('private/operator-session.json');path='/api/instances/'+target
 outcomes={}
 for name,url,body,headers in [
  ('duplicate',path+'/novnc-start',{'attempt':str(uuid4()),'rate':2},{}),
  ('foreign-release',path+'/novnc-release-control',{'attempt':row['attempt'],'next_attempt':str(uuid4())},{}),
  ('bad-rate',path+'/novnc-start',{'attempt':str(uuid4()),'rate':15},{}),
  ('wrong-instance','/api/instances/'+str(uuid4())+'/novnc-release-control',{'attempt':row['attempt'],'next_attempt':str(uuid4())},{}),
  ('bad-csrf',path+'/novnc-stop',{'attempt':row['attempt']},{'X-Kodi-Lab-CSRF':'invalid'}),
  ('bad-origin',path+'/novnc-stop',{'attempt':row['attempt']},{'Origin':'https://example.invalid'})]:
  h={'Origin':base,'Cookie':'kodi_lab_session='+s['token'],'X-Kodi-Lab-CSRF':s['csrf'],**headers}
  with httpx.Client(trust_env=False,timeout=8) as client:q=client.post(base+url,json=body,headers=h)
  outcomes[name]=q.status_code;assert q.status_code in (403,409,422),outcomes
  assert a.ownership()[0]['attempt']==row['attempt']
 with httpx.Client(trust_env=False,timeout=3) as client:q=client.post(base+path+'/novnc-start',json={'attempt':str(uuid4()),'rate':2},headers={'Origin':base})
 outcomes['anonymous']=q.status_code;assert q.status_code in (401,403)
 lab.save('evidence/native-auth-negatives.json',outcomes)
 # Unclean transport loss while actual keyboard/button are held.
 call('focusCanvas');call('key',value='a',hold=True);call('down',x=450,y=290);c.wait(.15);held=a.xstate();assert held['keys'] and held['mask']&256
 ev("(()=>{window.phase1Rfb._sock._websocket.close();return true;})()")
 disconnect=resumed('faults2-disconnect');call('resetInput')
 lab.save('evidence/native-disconnect-held.json',{'held':held,**disconnect})
 restart_view();cookies=call('cookies');token=next(x['value']['value'] for x in cookies['cookies'] if x['name']=='kodi_lab_session');lab.save('private/logout-cookie.json',{'token':token})
 logout=ev("(async()=>{const q=await fetch('/logout',{method:'POST',body:new URLSearchParams({csrf_token:document.querySelector('meta[name=\"kodi-lab-csrf\"]').content})});return {status:q.status};})()")
 recovery=resumed('faults2-logout')
 with httpx.Client(trust_env=False,timeout=3) as client:q=client.get(base+'/api/instances/'+target,cookies={'kodi_lab_session':token})
 assert q.status_code==401;lab.save('evidence/native-logout.json',{'logout':logout,'reused_cookie':q.status_code,**recovery})
 call('login');restart_view()
 for role in ('web','broker'):
  exact=lab.load('private/services.json')[role];container=lab.client().containers.get(exact['id']);assert container.attrs['Image']==exact['image'];old=a.ownership()[0]
  began=time.time();container.pause()
  try:c.wait(4)
  finally:container.unpause()
  recovery=resumed('faults2-paused-'+role);state=lab.client().api.exec_inspect(old['exec_id']);assert not state['Running'];lab.save('evidence/native-pause-'+role+'.json',{'pause_seconds':time.time()-began,'exec_running':state['Running'],**recovery});restart_view()
 # Exact disposable broker crash/restart, without replacing production services.
 old=a.ownership()[0];exact=lab.load('private/services.json')['broker'];container=lab.client().containers.get(exact['id']);container.kill(signal='SIGKILL');c.wait(4);container.start();c.wait(1)
 recovery=resumed('faults2-broker-crash');lab.save('evidence/native-broker-crash.json',{'exec_running':lab.client().api.exec_inspect(old['exec_id'])['Running'],**recovery});restart_view()
 # Deliberately kill armed helper: uncertain held state must retain ownership until native Stop.
 call('focusCanvas');call('key',value='a',hold=True);c.wait(.1);held=a.xstate();w=a.workers();helper=next(p for p in w['processes'] if '/usr/local/lib/kodi-lab-novnc-view.py' in p['args']);q=lab.fence().exec_run(['kill','-KILL',str(helper['pid'])],user='1000:1000');assert q.exit_code==0;c.wait(4)
 blocked,_,_=a.remote('left');assert blocked.get('isError');rows=a.ownership();assert rows
 lab.save('evidence/native-helper-kill-fence.json',{'held':held,'after':a.xstate(),'ownership_retained':rows,'agent_rejected':True})
 trial.stop_native();assert not a.ownership();call('key',value='a',up=True)
 lab.save('evidence/native-helper-kill-stop-recovery.json',{'ownership_after_native_stop':a.ownership(),'native_stopped':not lab.fence().attrs['State']['Running']})
 trial.completed=True
except BaseException as error:
 lab.save('evidence/faults2-error.json',{'error':str(error),'traceback':traceback.format_exc()});print(traceback.format_exc(),flush=True)
finally:trial.close()
assert trial.completed
