"""Read-only reduction: whole browser trees, no immediate-release assumption."""
import json,math,statistics,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];e=ROOT/'evidence'
def load(p):return json.loads((e/p).read_text())
def dist(v):
 v=sorted(v);return {'n':len(v),'p50':statistics.median(v) if v else None,'p95':v[math.ceil(len(v)*.95)-1] if v else None,'max':max(v) if v else None}
rows=[json.loads(s) for s in (e/'browser-memory-continuous.jsonl').read_text().splitlines()];regular=[json.loads(s) for s in (e/'browser-memory.jsonl').read_text().splitlines()];out={}
for tag in sorted(set(x['browser_run'] for x in rows)):
 r=[x for x in rows if x['browser_run']==tag];b=[x for x in r if x['stage'].endswith('-blank')];g=load('browser-guard-'+tag+'.json') if (e/('browser-guard-'+tag+'.json')).exists() else {};base=g.get('baseline_rss_mib') or statistics.median(x['tree_rss_smaps_mib'] for x in b);pss=load(tag+'-blank.json')['summary']['tree_pss_mib']['median']
 stages={}
 for stage in sorted(set(x['stage'] for x in r)):
  q=[x for x in r if x['stage']==stage];stages[stage]={'n':len(q),'first_RSS':q[0]['tree_rss_smaps_mib'],'last_RSS':q[-1]['tree_rss_smaps_mib'],'peak_RSS':max(x['tree_rss_smaps_mib'] for x in q),'first_PSS':q[0]['tree_pss_mib'],'last_PSS':q[-1]['tree_pss_mib'],'peak_PSS':max(x['tree_pss_mib'] for x in q)}
 cpu=[]
 for prior,current in zip(r,r[1:]):
  old={(x['pid'],x['start']):x['ticks'] for x in prior['tree']};dt=(current['host_at']-prior['host_at'])/1000
  if dt>0:cpu.append(100*sum(x['ticks']-old[(x['pid'],x['start'])] for x in current['tree'] if (x['pid'],x['start'])in old)/os.sysconf('SC_CLK_TCK')/dt)
 extra=[x for x in regular if x.get('browser_run')==tag];all_samples=r+extra
 out[tag]={'explicit_stage_samples':len(extra),'peak_sampling':'All continuous and explicit stage observations','browser_CPU_one_core_percent':dist(cpu),'samples':len(r),'baseline_RSS_mib':base,'baseline_PSS_mib':pss,'peak_incremental_RSS_mib':max(x['tree_rss_smaps_mib'] for x in all_samples)-base,'peak_incremental_PSS_mib':max(x['tree_pss_mib'] for x in all_samples)-pss,'stages':stages,'guard':g}
process={}
for p in e.glob('process-samples*.jsonl'):
 rr=[json.loads(x) for x in p.read_text().splitlines()];cpu=[x['host_percent'] for x in rr if 'host_percent'in x];roles={}
 for role in ('native','web','broker'):
  q=[x['cgroups'][role] for x in rr if role in x['cgroups']];roles[role]={'cpu_one_core_percent':dist([x['one_core_percent'] for x in q if 'one_core_percent'in x]),'peak_memory_mib':max([x['memory_mib'] for x in q],default=None),'peak_working_set_mib':max([x['working_set_mib'] for x in q],default=None),'oom_kills':max([x['oom_kill'] for x in q],default=0)}
 process[p.name]={'samples':len(rr),'host_CPU_percent':dist(cpu),'min_available_mib':min(x['available_mib'] for x in rr),'cgroups':roles}
network={}
for line in (e/'browser-memory.jsonl').read_text().splitlines():
 x=json.loads(line)
 if x.get('network'):network.setdefault(x['stage'],[]).append(x)
network_rates={}
for tag,q in network.items():
 if len(q)<2:continue
 seconds=(q[-1]['host_at']-q[0]['host_at'])/1000
 network_rates[tag]={'sampled_seconds':seconds,'payload_in_KiB_per_s':(q[-1]['network']['bytesIn']-q[0]['network']['bytesIn'])/1024/seconds,'payload_out_KiB_per_s':(q[-1]['network']['bytesOut']-q[0]['network']['bytesOut'])/1024/seconds,'scope':'Browser WebSocket payload counters; excludes TLS/IP overhead.'}
(e/'reduced-network.json').write_text(json.dumps(network_rates,indent=2)+'\n')
(e/'reduced-memory-resources.json').write_text(json.dumps({'browser':out,'resources':process},indent=2)+'\n')
print(json.dumps({tag:{k:v for k,v in o.items() if k not in ('stages','guard')} for tag,o in out.items()},indent=2))
