"""One-shot admin actions against only the isolated stack; no automatic retries."""
import json
import os
from pathlib import Path
import re
import sys
import time
import httpx

os.umask(0o077)
ROOT=Path(__file__).resolve().parents[1]
BASE='http://127.0.0.1:18108'
client=httpx.Client(base_url=BASE,trust_env=False,timeout=120)
session_path=ROOT/'private/operator-session.json'
if session_path.exists():
    session=json.loads(session_path.read_text());client.cookies.set('kodi_lab_session',session['token'])
else:
    response=client.post('/login',data={'password':(ROOT/'private/admin-password').read_text().strip()},headers={'Origin':BASE})
    assert response.status_code==303,response.status_code
    html=client.get('/').text;csrf=re.search('name="kodi-lab-csrf" content="([^"]+)"',html).group(1)
    session={'token':client.cookies.get('kodi_lab_session'),'csrf':csrf};session_path.write_text(json.dumps(session))
headers={'Origin':BASE,'X-Kodi-Lab-CSRF':session['csrf']}
target=json.loads((ROOT/'private/target.json').read_text())['target']
stage=sys.argv[1]
def mutate(path,body,tag):
    intent=ROOT/f'private/{tag}-intent.json';assert not intent.exists(),'Inspect original intent; no repeated mutation'
    intent.write_text(json.dumps({'path':path,'body':body,'at':time.time()}))
    response=client.post(path,json=body,headers=headers)
    (ROOT/f'private/{tag}-response.json').write_text(response.text)
    assert response.status_code in (200,201,202),f'{response.status_code} {response.text[:1000]}'
    return response.json()
if stage in ('provision','start','stop','start-benchmark','stop-final','start-security','stop-security','start-cleanup','stop-cleanup'):
    action=stage.split('-')[0]
    result=mutate(f'/api/instances/{target}/{action}',{},'native-'+stage)
    print(json.dumps({'action':stage,'target':target,'result':result},indent=2))
elif stage=='status':
    response=client.get('/api/instances/'+target);assert response.status_code==200,response.text
    print(json.dumps(response.json(),indent=2))
elif stage=='mcp':
    preset=mutate('/api/mcp/presets',{'display_name':'Phase2 existing agent inspection screenshot and remote test','template_preset_id':'11000000-0000-4000-8000-000000000001','permissions':['target.inspect','target.visual','target.control']},'mcp-preset-unique')
    principal=mutate('/api/mcp/clients',{'display_name':'Phase2 agent boundary qualification','preset_id':preset['id']},'mcp-client')
    mutate('/api/mcp/clients/'+principal['id']+'/targets/'+target,{},'mcp-target-grant')
    mutate('/api/mcp/target-policies/'+target,{'preset_id':preset['id']},'mcp-target-policy')
    issued=mutate('/api/mcp/clients/'+principal['id']+'/credentials',{'expiration_seconds':3600},'mcp-credential')
    (ROOT/'private/mcp-token').write_text(issued['token'])
    credential=issued['credential'];(ROOT/'private/mcp-identity.json').write_text(json.dumps({'client':principal['id'],'credential':credential['id'],'target':target,'preset':preset['id']}))
    # Do not keep an extra readable token-bearing response copy.
    (ROOT/'private/mcp-credential-response.json').write_text(json.dumps({'credential':credential,'token':'[private token file]'}))
    print('Scoped temporary benchmark credential issued in isolated catalog')
elif stage=='revoke':
    identity=json.loads((ROOT/'private/mcp-identity.json').read_text())
    mutate('/api/mcp/clients/'+identity['client']+'/credentials/'+identity['credential']+'/revoke',{},'mcp-revoke')
    print('Temporary benchmark credential revoked')
else:raise SystemExit('provision|start|stop|status|mcp|revoke')
