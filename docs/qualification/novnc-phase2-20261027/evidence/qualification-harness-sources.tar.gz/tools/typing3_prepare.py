from pathlib import Path
r=Path(__file__).resolve().parents[1]
s=(r/'tools/typing2_native.py').read_text().replace('typing2','typing3')
s=s.replace(" assert text in json.dumps(observed),'Kodi edit field did not expose the typed text'", " lab.save('evidence/typing3-observation-limit.json',{'JSONRPC_edit_value_exposed':False,'acceptance':'Saved independent X11 screenshot must visibly contain the typed fixture text; do not substitute an empty GetLabel result.'})")
s=s.replace("observed=labels();lab.save('evidence/typing3-web-keyboard-field.json',{'expected':text+' web','labels':observed,'physical_mobile_acceptance':False});assert text+' web' in json.dumps(observed)","observed=labels();lab.save('evidence/typing3-web-keyboard-field.json',{'expected':text+' web','labels':observed,'physical_mobile_acceptance':False});a.screenshot('typing3-web-field')")
s=s.replace("before=labels();call('key',value='z');after=labels();assert before==after;lab.save('evidence/keyboard-focus-exclusion.json',{'before':before,'after':after})", "before=labels();call('key',value='z',hold=True);native=a.xstate();assert not native['keys'];call('key',value='z',up=True);after=labels();lab.save('evidence/keyboard-focus-exclusion.json',{'before':before,'after':after,'native_while_unfocused_key_held':native});a.screenshot('typing3-focus-excluded')")
(r/'tools/typing3_native.py').write_text(s)
