"""Bounded ordinary-viewer memory qualification; pixel probes are separate."""
import io,json,math,os,subprocess,threading,time,traceback
from pathlib import Path
import httpx
import lab
from monitor import Monitor
from browser_memory import Browser,proc
from drivers import Source
from acceptance_support import mcp

os.umask(0o077)
mon=Monitor();browser=None;source=None;watch=None;results=[];menu_expected={};cycles=[];browser_baseline=None

def wait(seconds):
    end=time.monotonic()+seconds
    while time.monotonic()<end:
        mon.check();time.sleep(min(.05,max(0,end-time.monotonic())))

def dist(v):
    v=sorted(v);return {'n':len(v),'p50':v[math.ceil(.5*len(v))-1] if v else None,'p95':v[math.ceil(.95*len(v))-1] if v else None,'max':max(v) if v else None}

class Pings:
    def __init__(self,tag,duration):
        self.tag=tag;self.rows=[];self.error=None;self.eid=None;self.thread=threading.Thread(target=self.run,args=(duration,),daemon=True);self.thread.start()
    def run(self,duration):
        try:
            code="""import json,time,signal
from kodi_lab.broker.client import BrokerClient
signal.alarm(35);c=BrokerClient(connect_timeout=1,read_timeout=2,write_timeout=2)
for i in range(N):
 t=time.monotonic();v=c.ping();assert v.status=='healthy';print(json.dumps({'at':time.time()*1000,'ms':(time.monotonic()-t)*1000}),flush=True);time.sleep(max(0,2-(time.monotonic()-t)))
""".replace('range(N)','range('+str(int(duration/2))+')')
            c=lab.client();web=lab.load('private/services.json')['web']['id'];self.eid=c.api.exec_create(web,['python','-u','-c',code],user='10001:10001',stdout=True,stderr=True)['Id'];lab.record('pings-'+self.tag,'exec',self.eid);buffer=b''
            with (lab.ROOT/('evidence/pings-'+self.tag+'.jsonl')).open('x') as f:
                for chunk in c.api.exec_start(self.eid,stream=True):
                    buffer+=chunk
                    while b'\n' in buffer:
                        line,buffer=buffer.split(b'\n',1);v=json.loads(line);self.rows.append(v);f.write(json.dumps(v)+'\n');f.flush()
            assert c.api.exec_inspect(self.eid)['ExitCode']==0
        except Exception as e:self.error=repr(e)

def frame_stats(probe):
    frames=probe['frames'];seconds=(probe['end']-probe['start'])/1000;times=[probe['start']]+[f['at'] for f in frames]+[probe['end']];gaps=[b-a for a,b in zip(times,times[1:])];bins=[0]*int(seconds)
    for f in frames[1:]:
        i=int((f['at']-probe['start'])/1000)
        if i<len(bins):bins[i]+=1
    return {'actual_fps':max(0,len(frames)-1)/seconds,'inter_frame_fps':(len(frames)-1)*1000/(frames[-1]['at']-frames[0]['at']) if len(frames)>1 else None,'distinct_ids':len({f['id'] for f in frames}),'transitions':max(0,len(frames)-1),'seconds':seconds,'max_gap_ms':max(gaps),'gap_ms':dist(gaps),'full_second_updates':bins,'samples':probe['samples'],'invalid':probe['invalid'],'backward_or_repeat_wrap':sum(b['id']<=a['id'] for a,b in zip(frames,frames[1:]))}

def stage(tag,duration,agents=False,probe=None,legacy=False,navigate=False):
    tag=os.environ.get('RUN_ID','')+tag
    mon.check();mon.stage=tag
    if probe:browser.call('probe',scene=probe,legacy=legacy)
    start=time.time()*1000;began=time.monotonic();samples=[];agent=[];actions=[];index=0;next_agent=began+1;next_action=began+1;next_sample=began;pings=Pings(tag,duration) if agents else None
    with httpx.Client(trust_env=False,timeout=3) as h,(lab.ROOT/('evidence/actions-'+tag+'.jsonl')).open('x') as journal:
        while time.monotonic()-began<duration:
            mon.check();now=time.monotonic()
            if now>=next_sample:
                sample=browser.sample(tag);samples.append(sample);next_sample+=1
                if browser_baseline is not None and sample['tree_rss_smaps_mib']-browser_baseline>256:
                    lab.save('evidence/browser-memory-safety-abort.json',{'stage':tag,'baseline_mib':browser_baseline,'sample':sample,'threshold_mib':256});mon.reason='browser peak incrementalRSS exceeded256MiB';mon.abort.set();mon.emergency_stop();raise RuntimeError(mon.reason)
                assert time.monotonic()-next_sample<1.5,'Browser sampling schedule overrun'
            if agents and index<8 and now>=next_agent:
                args={'target_id':lab.load('private/target.json')['target']};journal.write(json.dumps({'phase':'dispatch','tool':'inspect_ui_state','at':time.time()*1000})+'\n');journal.flush()
                value,ms,sent=mcp(h,'inspect_ui_state',args);agent.append({'sent':sent,'ms':ms});journal.write(json.dumps({'phase':'complete','sent':sent,'ms':ms})+'\n');journal.flush();index+=1;next_agent=began+1+index*2
            if navigate and len(actions)<8 and now>=next_action:
                action='Input.Right' if len(actions)%2==0 else 'Input.Left';journal.write(json.dumps({'phase':'dispatch','action':action,'at':time.time()*1000})+'\n');journal.flush();_,timing=lab.rpc(action);actions.append({'action':action,'expected':menu_expected[action],**timing});next_action=began+1+len(actions)*1.1
            wait(.04)
    end=time.time()*1000;display=browser.call('endProbe') if probe else None
    if pings:pings.thread.join(4);assert not pings.thread.is_alive() and not pings.error,pings.error
    summary={'tag':tag,'start':start,'end':end,'duration_s':(end-start)/1000,'browser_n':len(samples),'agent':dist([r['ms'] for r in agent]),'broker':dist([r['ms'] for r in pings.rows]) if pings else None,'pixel_sampler':probe,'legacy':legacy}
    for key in ('tree_rss_status_mib','tree_rss_smaps_mib','tree_pss_mib','tree_uss_mib','cdp_rss_status_mib'):
        values=[v[key] for v in samples];summary[key]={'first':values[0],'last':values[-1],'min':min(values),'max':max(values),'mean':sum(values)/len(values),'median':dist(values)['p50']}
    if display and probe=='frames':summary['frames']=frame_stats(display)
    if navigate:
        matches=[]
        for a in actions:
            native=next((v for v in source.rows if a['sent']<=v['at']<a['sent']+1100 and v['menu']==a['expected']),None);shown=next((v for v in display['menus'] if a['sent']<=v['at']<a['sent']+1100 and v['state']==a['expected']),None)
            matches.append({'native_ms':native['at']-a['sent'] if native else None,'display_ms':shown['at']-a['sent'] if shown else None})
        summary['menu_matches']=matches;summary['menu_latency']=dist([v['display_ms'] for v in matches if v['display_ms'] is not None])
    result={'summary':summary,'agent':agent,'actions':actions,'display':display,'pings':pings.rows if pings else []};lab.save('evidence/'+tag+'.json',result);results.append(summary);lab.save('evidence/stages.json',results)
    print(json.dumps({'stage':tag,'rss_peak':summary['tree_rss_status_mib']['max'],'pss_first_last':[summary['tree_pss_mib']['first'],summary['tree_pss_mib']['last']],'fps':summary.get('frames',{}).get('actual_fps'),'agent_p95':summary['agent']['p95']}),flush=True)
    mon.check();return summary

def latency_gate(baseline,on):
    checks={}
    for key in ('agent','broker'):
        a=baseline[key]['p95'];b=on[key]['p95'];checks[key]={'off_p95':a,'on_p95':b,'delta_ms':b-a,'increase_percent':100*(b/a-1),'fail':b>a*1.2 and b-a>100}
    checks['pass']=not any(v['fail'] for k,v in checks.items() if k!='pass');lab.save('evidence/latency-'+on['tag']+'.json',checks);assert checks['pass'],'Agent/broker hard regression'

def movie():
    lab.rpc('Player.Open',{'item':{'file':'/home/kodi/.kodi/userdata/phase1-numbered-motion.mp4'}});lab.rpc('GUI.SetFullscreen',{'fullscreen':True});lab.rpc('Player.SetRepeat',{'playerid':1,'repeat':'one'});wait(2);props,timing=lab.rpc('Player.GetProperties',{'playerid':1,'properties':['time','speed','repeat']});assert props['speed']==1 and props['repeat']=='one';lab.save('evidence/movie-start-'+str(time.time_ns())+'.json',{'properties':props,**timing})

def home():
    active,_=lab.rpc('Player.GetActivePlayers')
    for p in active:lab.rpc('Player.Stop',{'playerid':p['playerid']})
    lab.rpc('GUI.ActivateWindow',{'window':'home'});wait(1)
