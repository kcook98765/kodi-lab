"""Existing JPEG Web UI and expired-ticket/replay negatives in Firefox."""
import os,time,traceback,json
from uuid import uuid4
os.environ['RUN_ID']='jpeg1-'
import lab,core as c,acceptance_support as a
from trial import Trial
trial=Trial.__new__(Trial)
def ev(expression):return c.browser.call('evaluate',expression=expression)
try:
 trial.__init__('jpeg1',source=False);from auth_expire import run as expire;expire();from disarmed import run;run();target=lab.load('private/target.json')['target']
 # Issue the grant through the same human-facing authenticated CSRF endpoint.
 for name,delay in [('expired',10.5),('fresh',0)]:
  ticket=ev("(async()=>{const q=await fetch('/api/instances/"+target+"/novnc-start',{method:'POST',headers:{'Content-Type':'application/json','X-Kodi-Lab-CSRF':document.querySelector('meta[name=\"kodi-lab-csrf\"]').content},body:JSON.stringify({attempt:crypto.randomUUID(),rate:2})});return {status:q.status,...await q.json()};})()")
  assert ticket['status']==200;c.wait(delay)
  result=ev("new Promise(resolve=>{const ws=new WebSocket('wss://localhost:18109/api/instances/"+target+"/novnc',['novnc','view."+ticket['ticket']+"']);let binary=false;ws.onmessage=()=>{binary=true;ws.close();};ws.onclose=e=>resolve({code:e.code,binary});ws.onerror=()=>{};setTimeout(()=>{ws.close();resolve({timeout:true,binary});},4000);})")
  if name=='expired':assert not result['binary']
  else:assert result['binary'];c.wait(.5)
  replay=ev("new Promise(resolve=>{const ws=new WebSocket('wss://localhost:18109/api/instances/"+target+"/novnc',['novnc','view."+ticket['ticket']+"']);ws.onclose=e=>resolve({code:e.code});ws.onerror=()=>{};setTimeout(()=>{ws.close();resolve({timeout:true});},2000);})")
  assert not replay.get('timeout');a.clean('jpeg1-ticket-'+name);lab.save('evidence/native-ticket-'+name+'.json',{'first':result,'replay':replay,'wait_seconds':delay})
 c.browser.call('goto',url='https://localhost:18109/instances/'+target);c.wait(1)
 ready=ev("(()=>({enabled:!document.querySelector('[data-live-start]').disabled}))()");assert ready['enabled']
 c.browser.call('click',selector='[data-live-start]');c.wait(7)
 first=ev("(()=>{const i=document.querySelector('[data-live-image]');return {src:i.src,width:i.naturalWidth,height:i.naturalHeight,hidden:i.hidden,status:document.querySelector('[data-live-status]').textContent};})()")
 assert first['width']==640 and first['height']==360 and not first['hidden'],first
 c.wait(3);second=ev("(()=>{const i=document.querySelector('[data-live-image]');return {src:i.src,width:i.naturalWidth,height:i.naturalHeight,status:document.querySelector('[data-live-status]').textContent};})()")
 assert first['src']!=second['src'];c.browser.call('click',selector='[data-live-stop]');c.wait(.5);stop=ev("(()=>({hidden:document.querySelector('[data-live-image]').hidden,status:document.querySelector('[data-live-status]').textContent}))()")
 assert stop['hidden'];lab.save('evidence/native-JPEG-browser.json',{'first':first,'second':second,'stop':stop,'noVNC_active':bool(a.ownership())});assert not a.ownership();a.screenshot('jpeg1-after-JPEG');trial.completed=True
except BaseException as error:
 lab.save('evidence/jpeg1-error.json',{'error':str(error),'traceback':traceback.format_exc()});print(traceback.format_exc(),flush=True)
finally:trial.close()
assert trial.completed
