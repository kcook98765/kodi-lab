// Isolated deterministic qualification harness only. No production agent API.
const fs=require('fs'),path=require('path'),readline=require('readline');
const {Firefox}=require('./firefox_bidi.cjs');
const ROOT=path.resolve(__dirname,'..'),BASE='https://localhost:18109',engine='firefox',tag=process.env.RUN_ID||'phase2';
let ff,mode='blank',lastNetwork={bytesIn:0,bytesOut:0,wsOpen:0,wsClosed:0};
const nap=ms=>new Promise(r=>setTimeout(r,ms));
async function evaluate(fn,arg){return ff.evaluate(fn,arg);}
async function until(fn,arg,ms=7000){const end=Date.now()+ms;while(Date.now()<end){if(await evaluate(fn,arg))return;await nap(40);}throw Error('Browser condition deadline: '+await evaluate(()=>document.querySelector('#status')?.textContent||location.pathname));}
async function open(){ff=new Firefox(tag);return ff.launch();}
async function click(selector){
 const p=await evaluate(s=>{document.querySelector(s).scrollIntoView({block:'center'});const r=document.querySelector(s).getBoundingClientRect();return {x:Math.round(r.x+r.width/2),y:Math.round(r.y+r.height/2)};},selector);
 await ff.command('input.performActions',{context:ff.context,actions:[{type:'pointer',id:'mouse',parameters:{pointerType:'mouse'},actions:[{type:'pointerMove',x:p.x,y:p.y,duration:0},{type:'pointerDown',button:0},{type:'pointerUp',button:0}]}]});return p;
}
async function keys(value,hold=false,up=false){
 const special={ArrowLeft:'\uE012',ArrowUp:'\uE013',ArrowRight:'\uE014',ArrowDown:'\uE015',Enter:'\uE007',Escape:'\uE00C',Backspace:'\uE003',Shift:'\uE008'};
 const values=special[value]?[special[value]]:[...value];const actions=[];
 for(const value of values){const shift=!special[value]&&/^[A-Z_~!@#$%^&*()+{}|:\"<>?]$/.test(value);if(shift&&!up)actions.push({type:'keyDown',value:'\uE008'});if(!up)actions.push({type:'keyDown',value});if(!hold)actions.push({type:'keyUp',value});if(shift&&!hold)actions.push({type:'keyUp',value:'\uE008'});}
 const sent=Date.now();await ff.command('input.performActions',{context:ff.context,actions:[{type:'key',id:'keyboard',actions}]});return {sent,returned:Date.now(),value:special[value]?value:'[ordinary typing]',held:hold};
}
async function login(){
 await ff.goto(BASE+'/login');await until(()=>!!document.querySelector('input[name="password"]'));
 await click('input[name="password"]');await keys(fs.readFileSync(path.join(ROOT,'private/admin-password'),'utf8').trim());await click('button[type="submit"]');
 await until(()=>!!document.querySelector('meta[name="kodi-lab-csrf"]'));return {authenticated:true,origin:BASE,certificate_validation:true};
}
async function labPage(){
 if(!await evaluate(()=>!!document.querySelector('meta[name="kodi-lab-csrf"]')))await login();
 const pin=JSON.parse(fs.readFileSync(path.join(ROOT,'private/native-pin.json')));await ff.goto(BASE+'/instances/'+pin.instance+'/novnc-phase1');
 await until(()=>!!document.querySelector('#viewer')&&typeof document.querySelector('#start')?.onclick==='function');
 await evaluate(async()=>{
  const {default:RFB}=await import('/static/vendor/novnc/core/rfb.js');
  const m={network:{bytesIn:0,bytesOut:0,wsOpen:0,wsClosed:0}};window.phase1Metrics=m;
  const OriginalWS=window.WebSocket,send=OriginalWS.prototype.send;
  OriginalWS.prototype.send=function(data){m.network.bytesOut+=typeof data==='string'?new TextEncoder().encode(data).length:data.byteLength??data.size??0;return send.call(this,data);};
  window.WebSocket=new Proxy(OriginalWS,{construct(Target,args){const ws=Reflect.construct(Target,args);m.network.wsOpen++;ws.addEventListener('message',e=>m.network.bytesIn+=typeof e.data==='string'?new TextEncoder().encode(e.data).length:e.data.byteLength??e.data.size??0);ws.addEventListener('close',()=>m.network.wsClosed++);return ws;}});
  window.gestureMetrics=[];
  const gesture=RFB.prototype._handleGesture;
  RFB.prototype._handleGesture=function(event){window.gestureMetrics.push({at:Date.now(),phase:event.type,type:event.detail.type});return gesture.call(this,event);};
  const update=RFB.prototype._updateConnectionState;
  RFB.prototype._updateConnectionState=function(state){const result=update.call(this,state);if(state==='connected')window.phase1Rfb=this;if(state==='disconnected'&&window.phase1Rfb===this)window.phase1Rfb=null;return result;};
  const viewer=document.querySelector('#viewer');viewer.style.width='640px';viewer.style.height='360px';viewer.style.minHeight='0';viewer.style.maxWidth='640px';return true;
 });mode='inactive';return {page_loaded:true,origin:BASE,harness_only_instrumentation:true};
}
async function start(){
 const began=Date.now();await click('#start');
 await until(()=>document.querySelector('#status')?.textContent==='Viewing only'&&window.phase1Rfb?._fbWidth===640&&window.phase1Rfb?._fbHeight===360,null,10000);
 mode='novnc';return {startup_ms:Date.now()-began,rate:2,geometry:await evaluate(()=>({rfb:[phase1Rfb._fbWidth,phase1Rfb._fbHeight],target:[phase1Rfb._display._target.width,phase1Rfb._display._target.height],back:[phase1Rfb._display._backbuffer.width,phase1Rfb._display._backbuffer.height],viewOnly:phase1Rfb.viewOnly,css:phase1Rfb._display._target.getBoundingClientRect().toJSON()}))};
}
async function change(interactive){const began=Date.now();await click(interactive?'#take-control':'#release-control');await until(interactive=>window.phase1Rfb?.viewOnly===!interactive&&document.querySelector('#status')?.textContent===(interactive?'You control Kodi. Agent input is paused.':'Viewing only'),interactive,10000);return {mode:interactive?'interactive':'view-only',handoff_ms:Date.now()-began};}
async function stop(){const began=Date.now();if(await evaluate(()=>!document.querySelector('#stop')?.disabled)){await click('#stop');await until(()=>document.querySelector('#status')?.textContent==='Off',null,7000);}mode='disconnected';return {ui_stop_ms:Date.now()-began};}
async function sample(){
 const state=await evaluate(()=>{const d=window.phase1Rfb?._display;return {status:document.querySelector('#status')?.textContent||null,metrics:window.phase1Metrics||null,framebuffer:d?{width:d._target.width,height:d._target.height,queue:d._renderQ.length}:null};});
 if(state.metrics)lastNetwork=state.metrics.network;
 return {at:Date.now(),engine,mode,view:state,network:lastNetwork,processes:{processInfo:[]},heap:{usedSize:null},node_memory:process.memoryUsage()};
}
async function pointer(c){
 const r=await evaluate(()=>document.querySelector('#viewer canvas').getBoundingClientRect().toJSON());
 const x=Math.round(r.x+(c.x??320)),y=Math.round(r.y+(c.y??180));let actions=[{type:'pointerMove',x,y,duration:0}];
 if(c.action==='clickCanvas')actions.push({type:'pointerDown',button:c.button??0},{type:'pointerUp',button:c.button??0});
 if(c.action==='down')actions.push({type:'pointerDown',button:c.button??0});
 if(c.action==='up')actions.push({type:'pointerUp',button:c.button??0});
 if(c.action==='drag')actions.push({type:'pointerDown',button:0},{type:'pointerMove',x:x+70,y:y+40,duration:400},{type:'pointerUp',button:0});
 if(c.action==='touch')actions.push({type:'pointerDown',button:0},{type:'pause',duration:100},{type:'pointerUp',button:0});
 const sent=Date.now();await ff.command('input.performActions',{context:ff.context,actions:[{type:'pointer',id:c.action==='touch'?'touch':'mouse',parameters:{pointerType:c.action==='touch'?'touch':'mouse'},actions}]});return {sent,returned:Date.now(),target:[x,y],simulation:c.action==='touch'?'touch emulation':null};
}
async function wheel(c){const r=await evaluate(()=>document.querySelector('#viewer canvas').getBoundingClientRect().toJSON());const sent=Date.now();await ff.command('input.performActions',{context:ff.context,actions:[{type:'wheel',id:'wheel',actions:[{type:'scroll',x:Math.round(r.x+(c.x??300)),y:Math.round(r.y+(c.y??180)),deltaX:0,deltaY:c.delta??120,duration:100}]}]});return {sent,returned:Date.now(),simulation:'wheel/touchpad-scroll emulation'};}
async function touchPan(){const r=await evaluate(()=>document.querySelector('#viewer canvas').getBoundingClientRect().toJSON());const actions=[0,1].map(i=>({type:'pointer',id:'touch-pan-'+i,parameters:{pointerType:'touch'},actions:[{type:'pointerMove',x:Math.round(r.x+70+i*40),y:Math.round(r.y+200),duration:0},{type:'pointerDown',button:0},{type:'pointerMove',x:Math.round(r.x+70+i*40),y:Math.round(r.y+130),duration:400},{type:'pointerUp',button:0}]}));await ff.command('input.performActions',{context:ff.context,actions});await nap(300);return evaluate(()=>({gestures:window.gestureMetrics,physical_device_acceptance:false}));}
async function closePage(){if(mode==='novnc')await stop();await ff.closePage();mode='document-closed';return {viewer_document_closed:true};}
async function close(){if(mode==='novnc')await stop();return ff.close();}
async function probe(scene){return evaluate(scene=>{
 const c=document.createElement('canvas');c.width=scene==='frames'?208:4;c.height=scene==='frames'?48:1;const ctx=c.getContext('2d',{willReadFrequently:true});
 const s={frames:[],menus:[],samples:0,invalid:0,invalidAt:[],lastId:null,lastMenu:null,start:Date.now(),scene};window.memProbe=s;
 s.timer=setInterval(()=>{
  const source=window.phase1Rfb?._display?._target;if(!source?.width)return;const at=Date.now(),sx=source.width/1280,sy=source.height/720;
  if(scene==='frames'){
   ctx.drawImage(source,0,0,416*sx,96*sy,0,0,208,48);const q=ctx.getImageData(0,0,208,48).data;
   const bit=(x,y)=>{const i=(Math.floor(y*.5)*208+Math.floor(x*.5))*4;return q[i]+q[i+1]+q[i+2]>384;};let valid=bit(3,3),id=0;
   for(let j=0;j<12;j++){const b=bit(24+j*32,24);valid=valid&&bit(24+j*32,56)!==b;id+=Number(b)*2**j;}
   if(valid&&id!==s.lastId){if(s.frames.length<2000)s.frames.push({at,id});s.lastId=id;}if(!valid){s.invalid++;if(s.invalidAt.length<2000)s.invalidAt.push(at);}
  }else{
   const pts=[[544,425],[776,425],[200,180],[200,245]];for(let j=0;j<4;j++)ctx.drawImage(source,Math.floor(pts[j][0]*sx),Math.floor(pts[j][1]*sy),1,1,j,0,1,1);
   const p=ctx.getImageData(0,0,4,1).data,g=[p[1],p[5],p[9],p[13]];const state=g[0]>75&&g[0]>g[1]+20?1:g[1]>75&&g[1]>g[0]+20?2:g[2]>75&&g[2]>g[3]+20?3:g[3]>75&&g[3]>g[2]+20?4:0;
   if(state!==s.lastMenu){s.menus.push({at,state});s.lastMenu=state;}
  }s.samples++;
 },50);s.deadline=setTimeout(()=>{clearInterval(s.timer);s.timer=null;},30000);return {scene};
 },scene);}
async function endProbe(){return evaluate(()=>{const s=window.memProbe;if(!s)return null;clearInterval(s.timer);clearTimeout(s.deadline);s.timer=null;return {...s,timer:null,deadline:null,end:Date.now()};});}

const input=readline.createInterface({input:process.stdin});let chain=Promise.resolve();
input.on('line',line=>{chain=chain.then(async()=>{const c=JSON.parse(line);try{
 let result;
 if(c.action==='open')result=await open();else if(c.action==='page')result=await labPage();else if(c.action==='login')result=await login();else if(c.action==='start')result=await start();else if(c.action==='take')result=await change(true);else if(c.action==='release')result=await change(false);else if(c.action==='stop')result=await stop();else if(c.action==='sample')result=await sample();else if(c.action==='probe')result=await probe(c.scene);else if(c.action==='endProbe')result=await endProbe();else if(c.action==='key')result=await keys(c.value,c.hold,c.up);else if(['move','clickCanvas','down','up','drag','touch'].includes(c.action))result=await pointer(c);else if(c.action==='wheel')result=await wheel(c);else if(c.action==='touchPan')result=await touchPan();else if(c.action==='focusText'){await click('#keyboard');await click('#text-input');result={typing_field_focused:true};}else if(c.action==='expand'){await click('#expand');result=await evaluate(()=>({fullscreen:!!document.fullscreenElement,expanded:document.querySelector('main').classList.contains('expanded')}));}else if(c.action==='photo'){const r=await ff.command('browsingContext.captureScreenshot',{context:ff.context,origin:'viewport',format:{type:'image/png'}});fs.writeFileSync(path.join(ROOT,'evidence',c.name+'.png'),Buffer.from(r.data,'base64'));result={saved:c.name+'.png'};}else if(c.action==='closePage')result=await closePage();else if(c.action==='close')result=await close();else if(c.action==='focusCanvas'){await evaluate(()=>document.querySelector('#viewer canvas').focus());result={focused:true};}else if(c.action==='resetInput')result=await ff.command('input.releaseActions',{context:ff.context});else if(c.action==='cookies')result=await ff.command('storage.getCookies',{filter:{name:'kodi_lab_session'}});else if(c.action==='goto'){await ff.goto(c.url);result={navigated:true};}else if(c.action==='click'){result=await click(c.selector);}else if(c.action==='status')result=await evaluate(()=>({status:document.querySelector('#status').textContent,viewOnly:window.phase1Rfb?.viewOnly}));else if(c.action==='evaluate')result=await evaluate(c.expression);else throw Error('Unknown harness command');
 process.stdout.write(JSON.stringify({id:c.id,result})+'\n');if(c.action==='close'){input.close();process.stdin.destroy();}
 }catch(e){process.stdout.write(JSON.stringify({id:c.id,error:String(e).slice(0,700)})+'\n');}});});
process.on('SIGTERM',async()=>{try{await close();}finally{process.exit(143);}});
