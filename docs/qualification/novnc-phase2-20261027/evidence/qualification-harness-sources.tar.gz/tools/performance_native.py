"""One bounded integrated2FPS motion trial; no failed-budget retry or tuning."""
import os,time,traceback,json
os.environ['RUN_ID']='perf1-'
import lab,core as c,acceptance_support as a
from trial import Trial
from pathlib import Path
import hashlib
manifest=lab.load('evidence/build8-source.json')
assert all(hashlib.sha256((Path('/home/kyle/kodi-lab-worktrees/novnc-phase2-20261027')/p).read_bytes()).hexdigest()==h for p,h in manifest.items()),'Candidate changed; performance has NOT started.'
trial=Trial.__new__(Trial)
try:
 trial.__init__('perf1')
 c.movie();off=c.stage('motion-off-agents',20,agents=True)
 trial.start_view();a.flags(False,'perf1-view-only');before=c.stage('motion-fps-before',10,probe='frames');assert before['frames']['invalid']==0 and before['frames']['transitions']>=17 and before['frames']['max_gap_ms']<=1000
 on=c.stage('motion-view-only-agents',20,agents=True);c.latency_gate(off,on)
 take=c.browser.call('take');lab.save('evidence/perf1-take.json',take);a.flags(True,'perf1-interactive');interactive=c.stage('motion-interactive-agents',20,agents=True);c.latency_gate(off,interactive)
 c.stage('motion-ordinary-no-pixel-readback',40)
 after=c.stage('motion-fps-after',10,probe='frames');assert after['frames']['invalid']==0 and after['frames']['transitions']>=17 and after['frames']['max_gap_ms']<=1000
 trial.stop_view('motion-main')
 cycles=[]
 for index in range(5):
  start=trial.start_view();c.stage('cycle-'+str(index)+'-on',2);stop=trial.stop_view('cycle-'+str(index));offcycle=c.stage('cycle-'+str(index)+'-off',3);cycles.append({'index':index,'start':start,'stop':stop,'off':offcycle})
 lab.save('evidence/perf1-cycles.json',cycles)
 trial.stop_native();c.stage('native-stopped-disconnected',20);c.browser.call('closePage');c.stage('document-closed',30);trial.completed=True
except BaseException as error:
 lab.save('evidence/perf1-error.json',{'error':str(error),'traceback':traceback.format_exc()});print(traceback.format_exc(),flush=True)
finally:trial.close()
assert trial.completed
