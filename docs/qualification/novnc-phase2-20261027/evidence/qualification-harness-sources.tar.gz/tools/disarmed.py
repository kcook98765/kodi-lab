"""Negative transport test only: no authority response can ever arm these workers."""
import socket,struct,time
import lab,core as c,acceptance_support as a
def run():
 out=[];api=lab.client().api;n=lab.fence();assert not a.ownership() and not a.workers()['processes']
 for name,payload in [('no-response',b''),('untrusted-heartbeat',struct.pack('!BI',2,0)),('wrong-challenge',struct.pack('!BI',4,32)+b'0'*32)]:
  eid=api.exec_create(n.id,['/usr/bin/python3','-I','-B','/usr/local/lib/kodi-lab-novnc-view.py'],user='1000:1000',stdin=True,stdout=True,stderr=True,environment={'KODI_LAB_VIEW_MODE':'interactive','KODI_LAB_VIEW_RATE':'2'},tty=False)['Id'];lab.record('disarmed-'+name,'exec',eid)
  stream=api.exec_start(eid,socket=True);raw=stream._sock;raw.settimeout(3);challenge=raw.recv(4096);assert b'KLVNCARM' in challenge
  if payload:raw.sendall(payload)
  c.wait(2.2);state=api.exec_inspect(eid);assert not state['Running'] and state['ExitCode']!=0;w=a.workers();assert not w['processes'] and not w['sockets'];raw.close();stream.close();out.append({'case':name,'exec':eid,'running':False,'exit_code':state['ExitCode'],'challenge_seen':True,'native_workers_after':w})
 lab.save('evidence/native-disarmed-workers.json',out)
