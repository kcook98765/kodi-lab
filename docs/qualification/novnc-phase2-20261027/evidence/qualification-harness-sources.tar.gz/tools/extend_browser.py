from pathlib import Path
p=Path(__file__).with_name('browser.cjs');s=p.read_text();s=s.replace("else if(c.action==='status')", "else if(c.action==='cookies')result=await ff.command('storage.getCookies',{filter:{name:'kodi_lab_session'}});else if(c.action==='goto'){await ff.goto(c.url);result={navigated:true};}else if(c.action==='click'){result=await click(c.selector);}else if(c.action==='status')")
s=s.replace('Math.round(r.x+300),y:Math.round(r.y+180)','Math.round(r.x+(c.x??300)),y:Math.round(r.y+(c.y??180))')
p.write_text(s)
