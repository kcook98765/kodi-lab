"""Real600s controller expiry, unchanged session allowance, continuous memory."""
import os,time,traceback
from datetime import datetime
os.environ['RUN_ID']='lease1-'
import lab,core as c,acceptance_support as a
from trial import Trial
trial=Trial.__new__(Trial)
try:
 trial.__init__('lease1',source=False)
 c.home();trial.start_view();initial=a.ownership()[0];take=c.browser.call('take');active=a.ownership()[0]
 assert active['absolute_expires_at']==initial['absolute_expires_at'] and active['mode']=='interactive'
 eid=active['exec_id'];deadline=datetime.fromisoformat(active['absolute_expires_at']).timestamp();a.flags(True,'lease1-controller')
 lab.save('evidence/lease-admitted.json',{'initial':initial,'active':active,'take':take,'observed_at':time.time(),'absolute_unix':deadline,'initial_max_seconds':600})
 blocked,_,_=a.remote('right');assert blocked.get('isError')
 c.stage('controller-read-only',20,agents=True)
 remaining=deadline-time.time();assert 0<remaining<=600
 c.stage('controller-until-expiry',remaining+3)
 status=c.browser.call('status');assert status['status']=='Off',status
 cleanup=a.clean('lease1-expired');assert time.time()<=deadline+5
 result,elapsed,_=a.remote('left');assert not result.get('isError');state=lab.client().api.exec_inspect(eid);assert not state['Running']
 lab.save('evidence/lease-expiration.json',{'deadline_unix':deadline,'observed_unix':time.time(),'late_observation_seconds':time.time()-deadline,'status':status,'cleanup':cleanup,'controller_exec':{'id':eid,'running':state['Running'],'exit_code':state['ExitCode']},'agent_resumed_ms':elapsed})
 c.stage('expired-disconnected',20);trial.stop_native();c.browser.call('closePage');c.stage('document-closed',30);trial.completed=True
except BaseException as error:
 lab.save('evidence/lease1-error.json',{'error':str(error),'traceback':traceback.format_exc()});print(traceback.format_exc(),flush=True)
finally:trial.close()
assert trial.completed
