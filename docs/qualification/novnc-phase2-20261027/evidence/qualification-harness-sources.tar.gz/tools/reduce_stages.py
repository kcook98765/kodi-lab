"""Matched component costs and unchanged resource gates from raw native samples."""
import json,statistics,os,math,csv
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];e=ROOT/'evidence'
def avg(v):return sum(v)/len(v) if v else None
browsers=[json.loads(s) for s in (e/'browser-memory-continuous.jsonl').read_text().splitlines()];out={}
for p in e.glob('process-samples*.jsonl'):
 rr=[json.loads(x) for x in p.read_text().splitlines()];run=p.name.removeprefix('process-samples').removesuffix('-.jsonl');ids={(x['pid'],x['start']) for b in browsers if b['browser_run']==run for x in b['tree']}
 for stage in sorted(set(x['stage'] for x in rr)):
  q=[x for x in rr if x['stage']==stage];v={'n':len(q),'host_CPU_mean_percent':avg([x['host_percent'] for x in q if 'host_percent'in x]),'browser_CPU_one_core_mean_percent':avg([sum(p.get('one_core_percent',0) for pid,p in x['processes'].items() if (int(pid),p['start'])in ids) for x in q]),'combined_server_working_set_mean_mib':avg([sum(z['working_set_mib'] for z in x['cgroups'].values()) for x in q]),'combined_server_working_set_peak_mib':max(sum(z['working_set_mib'] for z in x['cgroups'].values()) for x in q),'server':{},'native_processes':{}}
  for role in ('native','web','broker'):
   cg=[x['cgroups'][role] for x in q if role in x['cgroups']];v['server'][role]={'CPU_one_core_mean_percent':avg([x['one_core_percent'] for x in cg if 'one_core_percent'in x]),'working_set_mean_mib':avg([x['working_set_mib'] for x in cg]),'working_set_peak_mib':max([x['working_set_mib'] for x in cg],default=0)}
  for kind in ('kodi.bin','Xvfb','X0tigervnc','vnc-helper','source-observer'):
   def select(row):return [p for p in row['processes'].values() if p.get('role')=='native' and (p.get('native_kind')==kind if kind in ('vnc-helper','source-observer') else p['comm']==kind)]
   v['native_processes'][kind]={'CPU_one_core_mean_percent':avg([sum(p.get('one_core_percent',0) for p in select(x)) for x in q]),'RSS_mean_mib':avg([sum(p['rss_pages']*os.sysconf('SC_PAGE_SIZE')/1048576 for p in select(x)) for x in q])}
  out[stage]=v
(e/'reduced-stages.json').write_text(json.dumps(out,indent=2)+'\n')
gates={};off=out.get('perf2-motion-off-agents')
if off:
 for name in ('perf2-motion-view-only-agents','perf2-motion-interactive-agents'):
  if name in out:
   on=out[name];delta=on['combined_server_working_set_mean_mib']-off['combined_server_working_set_mean_mib'];gates[name]={'server_incremental_working_set_mib':delta,'server_RAM_budget_mib':160,'server_RAM_pass':delta<=160,'host_CPU_off':off['host_CPU_mean_percent'],'host_CPU_on':on['host_CPU_mean_percent']}
(e/'resource-gates.json').write_text(json.dumps(gates,indent=2)+'\n')
reduced=json.loads((e/'reduced-memory-resources.json').read_text())['browser']
with (e/'browser-trend.csv').open('w',newline='') as f:
 writer=csv.writer(f,lineterminator="\n");writer.writerow(['run','seconds','stage','RSS_MiB','PSS_MiB','increment_RSS_MiB','increment_PSS_MiB']);first={}
 for b in browsers:
  tag=b['browser_run'];first.setdefault(tag,b['host_at']);base=reduced[tag];writer.writerow([tag,(b['host_at']-first[tag])/1000,b['stage'],b['tree_rss_smaps_mib'],b['tree_pss_mib'],b['tree_rss_smaps_mib']-base['baseline_RSS_mib'],b['tree_pss_mib']-base['baseline_PSS_mib']])
print(json.dumps(gates,indent=2))
