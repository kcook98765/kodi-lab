"""Read-only comparison against campaign admission evidence, no restoration writes."""
import json,hashlib,subprocess,time
from pathlib import Path
import lab
old=lab.load('private/inventory-before.json');ids=[x['Id'] for x in old];after=json.loads(subprocess.check_output(['docker','inspect',*ids]));lab.save('private/inventory-after.json',after);by={x['Id']:x for x in after};drift=[]
for original in old:
 actual=by[original['Id']]
 for key in ('Id','Image','Config','HostConfig','Mounts','RestartCount'):
  if actual[key]!=original[key]:drift.append({'id':actual['Id'],'field':key})
 for key in ('Running','StartedAt','FinishedAt','Paused','Restarting','OOMKilled'):
  if actual['State'][key]!=original['State'][key]:drift.append({'id':actual['Id'],'field':'State.'+key})
 if actual['NetworkSettings']['Networks']!=original['NetworkSettings']['Networks']:drift.append({'id':actual['Id'],'field':'networks'})
assert not drift,drift
services={x['Config']['Labels'].get('com.docker.compose.service'):x for x in after if x['Config']['Labels'].get('com.docker.compose.project')=='kodi-lab-remote'}
assert set(services)=={'web','broker','repository'} and all(x['State']['Health']['Status']=='healthy' for x in services.values())
tables=['agent_workspaces','managed_diagnostic_captures','development_sessions','development_session_policy'];campaign=lab.ROOT.parent/'autonomous-campaign3-20261026'
code="""import sqlite3,json
c=sqlite3.connect('file:/var/lib/kodi-lab/database/kodi-lab.db?mode=ro',uri=True);c.row_factory=sqlite3.Row;c.execute('pragma query_only=on');c.execute('begin');assert c.execute('pragma integrity_check').fetchone()[0]=='ok';assert not c.execute('pragma foreign_key_check').fetchall();r={'schema':c.execute('select version_num from alembic_version').fetchone()[0]}
"""
code+='\n'.join('r[%r]=[dict(x) for x in c.execute(%r)]'%(t,'select * from '+t) for t in tables)
code+='\n'+(campaign/'tools/operation_idle.py').read_text()+'\nr["idle"]=snapshot_idle(c)\nprint(json.dumps(r))'
x=lab.client().containers.get(services['web']['Id']).exec_run(['python','-c',code]);assert x.exit_code==0;db=json.loads(x.output);lab.save('private/database-after.json',db);before=lab.load('private/database-before.json');assert db==before
historical=lab.load('private/prior-evidence-hashes.json');bad=[]
# Keys are exact paths recorded before Phase 2.
for p,h in historical.items():
 file=Path(p)
 if not file.is_absolute():file=lab.ROOT.parent/p
 expected=h['sha256'] if isinstance(h,dict) else h
 if hashlib.sha256(file.read_bytes()).hexdigest()!=expected:bad.append(p)
assert not bad,bad
registry={}
for record in ['opencode-global-before.json','firefox-registry-before.json']:
 hashes=lab.load('private/'+record);assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in hashes.items());registry[record]=len(hashes)
for path,head in [('/home/kyle/kodi-lab','775904bd73d0ddd0ad19482db4d59e90c0c55b8e'),('/home/kyle/kodi-lab-worktrees/novnc-phase1-20261026','dccf14471e005ec31a606cbb3ba10f9381092cc9')]:
 assert subprocess.check_output(['git','-C',path,'rev-parse','HEAD'],text=True).strip()==head
 assert not subprocess.check_output(['git','-C',path,'status','--porcelain'],text=True).strip()
assert Path('/etc/kodi-lab/web-admin-lan/nginx.conf').read_bytes()==(lab.ROOT.parent/'novnc-phase1g-v17-2fps-20261027/private/nginx-before.conf').read_bytes()
result={'at':time.time(),'original_containers':len(old),'original_container_drift':drift,'production_services':{name:{'id':x['Id'],'image':x['Image'],'healthy':True,'restarts':x['RestartCount']} for name,x in services.items()},'schema':db['schema'],'workspace_generation':db['agent_workspaces'][0]['generation'],'diagnostics':len(db['managed_diagnostic_captures']),'idle_tables':len(db['idle']['checked_tables']),'prior_evidence_hashes_unchanged':len(historical),'main_and_prototype_clean_unchanged':True,'production_ingress_unchanged':True,'global_configuration_and_browser_registry_unchanged':registry}
lab.save('evidence/preservation-final.json',result);print(json.dumps(result,indent=2))
