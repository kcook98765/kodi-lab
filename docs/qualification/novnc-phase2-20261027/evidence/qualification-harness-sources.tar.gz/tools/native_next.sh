#!/usr/bin/env bash
set -euo pipefail
root=/home/kyle/kodi-lab-deployment/novnc-phase2-interactive-20261027
py=/home/kyle/kodi-lab-worktrees/novnc-phase2-20261027/.venv/bin/python
"$py" -c 'import json;from pathlib import Path;p=Path("/home/kyle/kodi-lab-deployment/novnc-phase2-interactive-20261027");assert json.loads((p/"evidence/result-lease1.json").read_text())["completed"];assert not (p/"evidence/browser-memory-safety-abort.json").exists()'
cp "$root/evidence/app-images.json" "$root/evidence/build6-app-images.json"
"$py" "$root/tools/prepare_build7.py" > "$root/evidence/build7-driver.log" 2>&1
"$py" "$root/tools/faults_native.py" > "$root/evidence/faults1-driver.log" 2>&1
"$py" "$root/tools/jpeg_native.py" > "$root/evidence/jpeg1-driver.log" 2>&1
"$py" "$root/tools/performance_native.py" > "$root/evidence/perf1-driver.log" 2>&1
