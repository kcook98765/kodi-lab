"""Remove only the inert Unix socket left by this campaign's deliberate SIGKILL."""
import json,re
import lab,acceptance_support as a
from pathlib import Path
def run():
 source=lab.ROOT/'evidence/native-compound-crash-after.json'
 if not source.exists() or (lab.ROOT/'evidence/compound-crash-fixture-socket-retired.json').exists():return
 before=lab.load('private/native-helper1-stopped.json');recovery=lab.load('evidence/native-compound-crash-recovery.json');n=lab.fence();assert n.id==recovery['container'] and n.attrs['State']['StartedAt']!=before['State']['StartedAt'];assert not a.ownership() and not a.workers()['processes'];native=a.xstate();assert not native['keys'] and not native['mask']&0x1f00
 paths=[x['path'] for x in json.loads(source.read_text())['workers']['sockets']];assert len(paths)==1 and re.fullmatch(r'/run/kodi/view-[A-Za-z0-9_-]+/rfb.sock',paths[0])
 code="""import os,fcntl,stat,json
from pathlib import Path
lock=os.open('/run/kodi/novnc-phase1.lock',os.O_RDWR|os.O_NOFOLLOW);fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
p=Path(PATH);d=p.parent;s=p.lstat();ds=d.lstat();assert stat.S_ISSOCK(s.st_mode) and s.st_uid==1000 and stat.S_ISDIR(ds.st_mode) and ds.st_uid==1000 and set(x.name for x in d.iterdir())=={'rfb.sock'};p.unlink();d.rmdir();os.close(lock);print(json.dumps({'removed_exact_inert_socket':str(p)}))
""".replace('PATH',repr(paths[0]));result=a.native_code(code);lab.save('evidence/compound-crash-fixture-socket-retired.json',{'scope':'Only exact inert artifact from deliberately killed native helper/X0, after verified Stop and fresh native incarnation. No ordinary worker or input authority changed.','neutral_input':native,'result':result});assert not a.workers()['sockets']
