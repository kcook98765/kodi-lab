"""Finite trusted-package install with unchanged host safety thresholds."""
from pathlib import Path
import json,os,subprocess,time
import lab
os.umask(0o077)
assert not lab.client().containers.list(filters={'label':'io.kodi-lab.managed=true'})
before={x.id for x in lab.client().containers.list(all=True)}
p=subprocess.Popen(['/home/kyle/kodi-lab-worktrees/novnc-phase2-20261027/.venv/bin/python',str(lab.ROOT/'tools/lab.py'),'install'],stdout=(lab.ROOT/'evidence/install-driver.log').open('w'),stderr=subprocess.STDOUT)
old=None;recent=[];started=time.monotonic();rows=[]
try:
 with (lab.ROOT/'evidence/install-host-samples.jsonl').open('x') as out:
  while p.poll() is None:
   ticks=[int(x) for x in Path('/proc/stat').read_text().splitlines()[0].split()[1:]];mem={x.split(':')[0]:int(x.split()[1]) for x in Path('/proc/meminfo').read_text().splitlines()};r={'at':time.time(),'mono':time.monotonic(),'ticks':ticks,'available_mib':mem['MemAvailable']/1024}
   if old:
    d=[b-a for a,b in zip(old['ticks'],ticks)];r['cpu_percent']=100*(sum(d[:8])-d[3]-d[4])/sum(d[:8]);recent=(recent+[r['cpu_percent']])[-10:]
   rows.append(r);out.write(json.dumps(r)+'\n');out.flush();old=r
   if (len(recent)==10 and min(recent)>80) or r['available_mib']<2048 or time.monotonic()-started>1000:
    lab.save('evidence/install-safety-abort.json',{'trigger':r,'recent':recent});raise RuntimeError('Install safety threshold exceeded')
   time.sleep(1)
 assert p.returncode==0,(lab.ROOT/'evidence/install-driver.log').read_text()[-2000:]
 lab.save('evidence/install-watch.json',{'exit':p.returncode,'seconds':time.monotonic()-started,'samples':len(rows),'minimum_available_mib':min(x['available_mib'] for x in rows),'peak_cpu_percent':max([x.get('cpu_percent',0) for x in rows]),'safety_abort':False})
 print('Reviewed native install complete',len(rows),'host samples')
except BaseException:
 # Stop only the journaled campaign installer and its exact new r4 validation
 # image. No production/container-name cleanup or host-wide operation.
 for e in [json.loads(x) for x in (lab.ROOT/'private/resources.jsonl').read_text().splitlines()]:
  if e['kind']=='container' and e['role']=='runtime-install':
   x=lab.client().containers.get(e['id']);assert x.labels.get('io.kodi-lab.novnc-phase2')=='20261027';x.stop(timeout=3)
 p.terminate();p.wait(timeout=5);raise
