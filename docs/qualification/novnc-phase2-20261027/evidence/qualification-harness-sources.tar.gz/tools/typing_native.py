"""Firefox typing in Kodi's real Add Source dialog, canceled without saving."""
import os,time,traceback,json
os.environ['RUN_ID']='typing1-'
import lab,core as c,acceptance_support as a
from trial import Trial
trial=Trial.__new__(Trial)
def call(action,**kw):c.mon.check();v=c.browser.call(action,**kw);c.wait(.25);return v

def labels():return lab.rpc('XBMC.GetInfoLabels',{'labels':['Control.GetLabel(310)','System.CurrentWindow','System.CurrentControl']})[0]
try:
 trial.__init__('typing1',source=False)
 lab.rpc('GUI.ActivateWindow',{'window':'filemanager'});c.wait(.4);a.screenshot('typing-filemanager-fixture')
 trial.start_view();call('take');a.flags(True,'typing-controller')
 steps=[]
 for i in range(6):
  state=a.ui();steps.append(state)
  if 'add source' in json.dumps(state).lower():break
  call('key',value='ArrowDown')
 lab.save('evidence/typing-filemanager-navigation.json',steps)
 call('key',value='Enter');c.wait(.3);lab.save('evidence/typing-source-dialog.json',a.ui())
 call('key',value='Enter');c.wait(.3);lab.save('evidence/typing-keyboard-before.json',{'ui':a.ui(),'labels':labels()})
 call('photo',name='typing-keyboard-before')
 text='Phase2 test';call('key',value=text);c.wait(.4);observed=labels();lab.save('evidence/typing-physical-keyboard-simulation.json',{'typed':text,'labels':observed,'ui':a.ui(),'physical_device_acceptance':False});a.screenshot('typing-desktop')
 assert text in json.dumps(observed),'Kodi edit field did not expose the typed text'
 call('focusText');call('key',value=' web');c.wait(.3);observed=labels();lab.save('evidence/typing-web-keyboard-field.json',{'expected':text+' web','labels':observed,'physical_mobile_acceptance':False});assert text+' web' in json.dumps(observed)
 # Focus a normal Web button, send an ordinary key, and prove it is not sent
 # to Kodi. This verifies capture follows viewer/typing-field focus.
 call('evaluate',expression="(()=>{document.querySelector('#expand').focus();return true})()")
 before=labels();call('key',value='z');after=labels();assert before==after;lab.save('evidence/keyboard-focus-exclusion.json',{'before':before,'after':after})
 call('focusCanvas');call('key',value='Escape');call('key',value='Escape');call('key',value='Escape')
 before=call('evaluate',expression="(()=>{document.querySelector('#viewer').style.cssText='';return document.querySelector('#viewer').getBoundingClientRect().toJSON()})()")
 expanded=call('expand');after=call('evaluate',expression="document.querySelector('#viewer').getBoundingClientRect().toJSON()");assert after['height']>before['height'];lab.save('evidence/expanded-viewer-geometry.json',{'before':before,'after':after,'ui':expanded});call('expand')
 try:pan=call('touchPan');lab.save('evidence/two-finger-pan-simulation.json',pan)
 except Exception as error:lab.save('evidence/two-finger-pan-simulation.json',{'supported':False,'error':str(error),'physical_device_acceptance':False})
 call('release');trial.stop_view('typing-complete');c.stage('disconnected',5);trial.completed=True
except BaseException as error:
 lab.save('evidence/typing1-error.json',{'error':str(error),'traceback':traceback.format_exc()});print(traceback.format_exc(),flush=True)
finally:trial.close()
assert trial.completed
