"""Independent host safety and read-only per-process/thread/cgroup accounting."""
import json,os,time,threading
from pathlib import Path
import lab
HZ=os.sysconf('SC_CLK_TCK');CG=Path('/sys/fs/cgroup')
def stat(p):
    raw=(p/'stat').read_text();f=raw[raw.rfind(')')+2:].split();return {'ppid':int(f[1]),'ticks':int(f[11])+int(f[12]),'start':int(f[19]),'rss_pages':int(f[21])}
class Monitor:
    def __init__(self):
        self.stop_event=threading.Event();self.abort=threading.Event();self.stage='preparation';self.rows=[];self.used=float(os.environ.get('PRIOR_ACTIVE_SECONDS','0'));self.reason=None;self.stop_lock=threading.RLock();self.thread=threading.Thread(target=self.run,daemon=True)
    def start(self):self.thread.start()
    def check(self):
        if self.abort.is_set():raise RuntimeError('SAFETY ABORT: '+str(self.reason))
    def snapshot(self):
        now=time.monotonic();out={'at':time.time()*1000,'mono':now,'stage':self.stage,'host_ticks':[int(x) for x in Path('/proc/stat').read_text().splitlines()[0].split()[1:]],'processes':{},'threads':{},'cgroups':{}}
        mem={x.split(':')[0]:int(x.split()[1]) for x in Path('/proc/meminfo').read_text().splitlines()};out['available_mib']=mem['MemAvailable']/1024
        e=lab.load('private/native.json');services=lab.load('private/services.json');api=lab.client();n=api.containers.get(e['id']);n.reload();a=n.attrs;assert a['Image']==e['image'] and a['Config']['Labels']['io.kodi-lab.instance-id']==e['target'] and not a['Mounts'] and not a['HostConfig']['PortBindings'];out['native_running']=a['State']['Running'];out['native_started']=a['State']['StartedAt']
        api.close()
        groups={**{k:v['id'] for k,v in services.items()},'native':e['id']}
        for role,cid in groups.items():
            path=CG/'system.slice'/('docker-'+cid+'.scope')
            if path.exists():
                cpu={k:int(v) for k,v in (x.split() for x in (path/'cpu.stat').read_text().splitlines())};ev={k:int(v) for k,v in (x.split() for x in (path/'memory.events').read_text().splitlines())};out['cgroups'][role]={'id':cid,'cpu_usec':cpu['usage_usec'],'memory_mib':int((path/'memory.current').read_text())/1048576,'working_set_mib':(int((path/'memory.current').read_text())-int(dict(x.split() for x in (path/'memory.stat').read_text().splitlines()).get('inactive_file','0')))/1048576,'oom_kill':ev.get('oom_kill',0)}
        for p in Path('/proc').iterdir():
            if not p.name.isdigit():continue
            try:
                row=stat(p);row['comm']=(p/'comm').read_text().strip();row['cgroup']=(p/'cgroup').read_text().strip();row['role']=next((role for role,cid in groups.items() if cid in row['cgroup']),'host')
                if row['role']=='native' and row['comm'].startswith('python'):
                    try:
                        args=(p/'cmdline').read_bytes().split(b'\0')
                        if b'/usr/local/lib/kodi-lab-novnc-view.py' in args:row['native_kind']='vnc-helper'
                        elif any(b'Read-only X11 wire ROI observer' in x for x in args):row['native_kind']='source-observer'
                    except OSError:pass
                out['processes'][p.name]=row
                if row['role']=='native' and row['comm'] in ('kodi.bin','Xvfb','X0tigervnc'):
                    for t in (p/'task').iterdir():
                        try:tr=stat(t);tr['comm']=(t/'comm').read_text().strip();tr['pid']=int(p.name);out['threads'][t.name]=tr
                        except (OSError,ValueError,IndexError):pass
            except (OSError,ValueError,IndexError):pass
        return out
    def run(self):
        old=None;recent=[];scheduled=time.monotonic()
        try:
            with (lab.ROOT/('evidence/process-samples'+os.environ.get('RUN_ID','')+'.jsonl')).open('x') as f:
                while not self.stop_event.is_set():
                    row=self.snapshot()
                    if old:
                        dt=row['mono']-old['mono'];delta=[b-a for a,b in zip(old['host_ticks'],row['host_ticks'])];total=sum(delta[:8]);row['host_percent']=100*(total-delta[3]-delta[4])/total;recent=(recent+[row['host_percent']])[-10:]
                        if row['native_running'] or old['native_running']:self.used+=dt
                        for section in ('processes','threads'):
                            for key,v in row[section].items():
                                p=old[section].get(key)
                                if p and p['start']==v['start']:v['one_core_percent']=100*(v['ticks']-p['ticks'])/(HZ*dt)
                        for key,v in row['cgroups'].items():
                            p=old['cgroups'].get(key)
                            if p and p['id']==v['id']:v['one_core_percent']=100*(v['cpu_usec']-p['cpu_usec'])/(dt*1e6)
                    row['cumulative_active_seconds']=self.used;self.rows.append(row);f.write(json.dumps(row)+'\n');f.flush();os.fsync(f.fileno());old=row
                    reason=None
                    if len(recent)==10 and min(recent)>80:reason='host CPU >80% for ten consecutive one-second samples'
                    if row['available_mib']<2048:reason='available memory below 2048 MiB'
                    if any(x['oom_kill'] for x in row['cgroups'].values()):reason='OOM kill observed'
                    native_limit=1800
                    row['native_budget_seconds']=native_limit
                    if self.used>native_limit:reason=f'{native_limit}-second cumulative native budget reached'
                    if reason:
                        self.reason=reason;self.abort.set();lab.save('evidence/safety-abort.json',{'reason':reason,'trigger':row,'recent_host_cpu':recent,'at':time.time()})
                        self.emergency_stop();return
                    scheduled+=1;self.stop_event.wait(max(0,scheduled-time.monotonic()))
        except BaseException as error:
            self.reason='monitor failure: '+repr(error);self.abort.set();lab.save('evidence/monitor-error.json',{'error':str(error),'at':time.time()});self.emergency_stop()
    def stop_native(self,tag):
        with self.stop_lock:
            n=lab.fence();n.reload()
            if n.attrs['State']['Running']:
                try:lab.mutate('stop',tag)
                except Exception as e:lab.save('evidence/'+tag+'-api-error.json',{'error':str(e)})
                n.reload()
                if n.attrs['State']['Running']:n.stop(timeout=3)
            n.reload();assert not n.attrs['State']['Running']
    def emergency_stop(self):
        try:self.stop_native('safety-stop')
        except Exception as e:lab.save('evidence/safety-stop-error.json',{'error':str(e)})
    def close(self):self.stop_event.set();self.thread.join(15)
