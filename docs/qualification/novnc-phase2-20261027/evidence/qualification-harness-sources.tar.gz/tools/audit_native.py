"""Exact exec and browser PID/start observations before disposable deprovision."""
import json,time
from pathlib import Path
import lab,docker
n=lab.fence();assert not n.attrs['State']['Running'];api=lab.client().api;events={}
for line in (lab.ROOT/'evidence/native-exec-events.jsonl').read_text().splitlines():
 x=json.loads(line)
 if x['kind'] in ('view','proof','source'):events.setdefault(x['exec'],x['kind'])
execs=[]
for eid,kind in events.items():
 try:x=api.exec_inspect(eid)
 except docker.errors.NotFound:
  execs.append({'id':eid,'kind':kind,'running':False,'exit_code':None,'proof':'Exact container is stopped; historical Docker exec metadata unavailable. Exit status not recollected.'});continue
 assert not x['Running'];assert x['ContainerID']==n.id and not x['ProcessConfig']['privileged'] and not x['ProcessConfig']['tty'];execs.append({'id':eid,'kind':kind,'running':False,'exit_code':x['ExitCode'],'user':x['ProcessConfig']['user']})
pairs=set()
for file in ('browser-memory.jsonl','browser-memory-continuous.jsonl'):
 for line in (lab.ROOT/'evidence'/file).read_text().splitlines():
  x=json.loads(line)
  for p in x.get('tree',[]):pairs.add((p['pid'],p['start']))
for pid,start in pairs:
 p=Path('/proc')/str(pid)
 try:assert int(p.joinpath('stat').read_text().split(') ',1)[1].split()[19])!=start,(pid,start)
 except FileNotFoundError:pass
rows=[]
for p in (lab.ROOT/'evidence').glob('result-*.json'):
 x=json.loads(p.read_text());assert x['native_stopped'] and not x['safety_abort'];rows.append({'trial':p.stem.removeprefix('result-'),**x})
lab.save('evidence/native-audit.json',{'at':time.time(),'container':n.id,'native_stopped':True,'execs':execs,'tracked_native_execs_stopped':len(execs),'sampled_browser_PID_start_identities_gone':len(pairs),'trials':rows,'cumulative_native_seconds':lab.load('evidence/active-budget.json')['monitor_cumulative_seconds'],'native_budget_seconds':1800,'performance_agent_gate_failure_retained':not lab.load('evidence/latency-perf2-motion-interactive-agents.json')['pass']});print('Exact native execs stopped:',len(execs),'sampled browser identities gone:',len(pairs),'trials:',len(rows))
