"""Existing lifecycle Stop + restart invalidates immutable human viewer pin."""
import os,time,traceback
os.environ['RUN_ID']='identity1-'
import lab,core as c,acceptance_support as a
from trial import Trial
trial=Trial.__new__(Trial)
try:
 trial.__init__('identity1',source=False);c.home();trial.start_view();c.browser.call('take');old=lab.load('private/native-pin.json');oldrow=a.ownership()[0]
 c.browser.call('focusCanvas');observations=[]
 for index in range(6):
  xy=[200+index*35,220+index*8];sent=c.browser.call('move',x=xy[0],y=xy[1]);native=a.xstate();observed=time.time()*1000;assert native['root_xy']==xy;observations.append({'kind':'pointer','sent_ms':sent['sent'],'observed_ms':observed,'delivery_upper_bound_ms':observed-sent['sent'],'native':native})
  sent=c.browser.call('key',value='a',hold=True);native=a.xstate();observed=time.time()*1000;assert 38 in native['keys'];observations.append({'kind':'key','sent_ms':sent['sent'],'observed_ms':observed,'delivery_upper_bound_ms':observed-sent['sent'],'native':native});c.browser.call('key',value='a',up=True)
 lab.save('evidence/native-input-delivery-observations.json',{'observations':observations,'pointer_upper_bound_ms':c.dist([x['delivery_upper_bound_ms'] for x in observations if x['kind']=='pointer']),'key_upper_bound_ms':c.dist([x['delivery_upper_bound_ms'] for x in observations if x['kind']=='key']),'method':'Actual Firefox WebDriver actions followed immediately by independent X11 queries. Includes query/exec/IPC overhead; bounds delivery, not exact device latency.'})
 c.browser.call('move',x=70,y=210);c.wait(.25);before_scroll=a.ui();a.screenshot('identity1-before-wheel');wheel=c.browser.call('wheel',x=70,y=210,delta=480);c.wait(.7);after_scroll=a.ui();a.screenshot('identity1-after-wheel');lab.save('evidence/native-scroll-effect.json',{'before':before_scroll,'after':after_scroll,'Kodi_control_changed':before_scroll!=after_scroll,'Firefox_wheel_command':wheel,'physical_touchpad_acceptance':False,'scope':'One Kodi Home sidebar wheel sequence; no generic widget or physical touchpad compatibility claim.'})
 trial.stop_native();assert not a.ownership();assert not lab.client().api.exec_inspect(oldrow['exec_id'])['Running'];c.wait(.5)
 lab.mutate('start','restart-identity1');trial.ledger('restart');deadline=time.monotonic()+30
 while time.monotonic()<deadline:
  c.mon.check();n=lab.fence()
  if n.attrs['State'].get('Health',{}).get('Status')=='healthy' and lab.status()['usability_state']=='usable':break
  c.wait(.2)
 else:raise RuntimeError('Restart readiness')
 assert n.attrs['State']['StartedAt']!=old['started'];c.browser.call('page');result=c.browser.call('evaluate',expression="(async()=>{document.querySelector('#start').click();await new Promise(r=>setTimeout(r,1400));return {status:document.querySelector('#status').textContent};})()")
 assert 'unavailable' in result['status'].lower(),result
 assert not a.ownership();assert not a.workers()['processes'];began=time.time();r=a.web_post('/api/instances/'+lab.load('private/target.json')['target']+'/remote-actions',{'action':'left'});ms=(time.time()-began)*1000;assert r.status_code==200;a.screenshot('identity1-stale-pin-independent')
 lab.save('evidence/native-incarnation-replacement.json',{'same_exact_container':n.id,'old_started':old['started'],'new_started':n.attrs['State']['StartedAt'],'old_controller_exec_stopped':True,'old_pin_rejected':result,'ownership':a.ownership(),'existing_Web_input_resumed_ms':ms,'scope':'Supported Stop/Start replaces the exact runtime incarnation; physical container replacement separately untested.'});trial.completed=True
except BaseException as error:
 lab.save('evidence/identity1-error.json',{'error':str(error),'traceback':traceback.format_exc()});print(traceback.format_exc(),flush=True)
finally:trial.close()
assert trial.completed
