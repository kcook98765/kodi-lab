"""Only this campaign's exact disposable identities; no production writes."""
from pathlib import Path
import hashlib,io,json,os,re,secrets,subprocess,tarfile,time
from uuid import uuid4
import docker,httpx
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT.parent/'novnc-phase1-20261026'
LABEL={'io.kodi-lab.novnc-phase2':'20261027'}
STATE='kodi-lab-novnc-phase2-state-20261027';SOCKET='kodi-lab-novnc-phase2-socket-20261027';NETWORK='kodi-lab-novnc-phase2-20261027';PORT=18108
PY='/home/kyle/kodi-lab-worktrees/novnc-phase2-20261027/.venv/bin/python'
os.umask(0o077)
def load(p):return json.loads((ROOT/p).read_text())
def save(p,v):(ROOT/p).write_text(json.dumps(v,indent=2)+'\n')
def client():return docker.from_env(timeout=4)
def record(role,kind,value):
 with (ROOT/'private/resources.jsonl').open('a') as f:f.write(json.dumps({'role':role,'kind':kind,'id':value,'at':time.time()})+'\n');f.flush();os.fsync(f.fileno())
def images():return load('evidence/app-images.json')['images']
def oneoff(role,code,*,volumes=None,image_role='web',input_text=None,install=False):
 c=client();options={}
 if install:options={'cap_add':['SETUID','SETGID'],'init':True}
 x=c.containers.create(images()[image_role],name='klnovnc2-'+role,entrypoint=['python','-c',code],network=NETWORK if install else 'none',volumes=volumes or {STATE:{'bind':'/var/lib/kodi-lab','mode':'rw'}},environment={'KODI_LAB_WEB_ALLOWED_HOSTS':'["127.0.0.1","192.168.2.191"]'},stdin_open=input_text is not None,read_only=True,tmpfs={'/tmp':'rw,noexec,nosuid,size=64m'},cap_drop=['ALL'],security_opt=['no-new-privileges:true'],labels=LABEL,**options)
 record(role,'container',x.id)
 with (ROOT/f'evidence/{role}.log').open('w') as out:r=subprocess.run(['docker','start','-ai' if input_text is not None else '-a',x.id],input=input_text,text=True,stdout=out,stderr=subprocess.STDOUT,timeout=1000 if install else 90)
 x.reload();assert x.attrs['State']['ExitCode']==0,(ROOT/f'evidence/{role}.log').read_text()[-2500:]
 return x

def initialize():
 c=client();assert not c.containers.list(filters={'label':'io.kodi-lab.managed=true'})
 for role,name in [('state',STATE),('socket',SOCKET)]:
  assert not c.volumes.list(filters={'name':name});v=c.volumes.create(name,labels=LABEL);record(role,'volume',v.name)
 assert not c.networks.list(names=[NETWORK]);n=c.networks.create(NETWORK,internal=True,labels=LABEL);record('app-network','network',n.id)
 password=secrets.token_urlsafe(32);(ROOT/'private/admin-password').write_text(password)
 code='''import sys
from kodi_lab.config import Settings
from kodi_lab.remote_lifecycle import initialize
from kodi_lab.storage.engine import create_database_engine,create_session_factory
from kodi_lab.auth.service import WebAuthenticationService
s=Settings(_env_file=None);print(initialize(s.data_root,s.database_url));WebAuthenticationService(create_session_factory(create_database_engine(s.database_url))).set_password(sys.stdin.read().strip());print('Fresh independent catalog initialized')
'''
 oneoff('initialize',code,input_text=password)
 print('Fresh isolated catalog initialized; production catalog not copied')

def install():
 code='''from dataclasses import asdict
import json
from kodi_lab.config import Settings
from kodi_lab.runtime.install import install_reviewed_runtime
r=install_reviewed_runtime('omega',settings=Settings(_env_file=None),novnc_phase1=True)
print(json.dumps(asdict(r),default=str))
'''
 oneoff('runtime-install',code,image_role='broker',volumes={STATE:{'bind':'/var/lib/kodi-lab','mode':'rw'},SOCKET:{'bind':'/run/kodi-lab','mode':'rw'},'/var/run/docker.sock':{'bind':'/var/run/docker.sock','mode':'rw'}},install=True)
 print('Reviewed experimental r4 installed and natively validated')

def register():
 target=str(uuid4());save('private/target-intent.json',{'target':target})
 code='''import json
from uuid import UUID
from sqlalchemy import text
from kodi_lab.config import Settings
from kodi_lab.storage.engine import create_database_engine,create_session_factory
from kodi_lab.storage.repositories import TargetRepository
from kodi_lab.domain import Target,TargetType,TargetAvailability,HealthStatus,ConnectionState,InstanceType
from kodi_lab.application.managed_instances import ManagedInstanceService,ExactRevisionSelection
from kodi_lab.runtime.recipes import load_novnc_phase1_recipe
s=Settings(_env_file=None);f=create_session_factory(create_database_engine(s.database_url));target=UUID('TARGET')
with f.begin() as db:
 row=db.execute(text("select runtime_revision_id,image_id from runtime_recipe_installations where state='ready' and recipe_revision=4")).one();revision=UUID(row[0]);image=row[1]
 TargetRepository(db).create(Target(id=target,name='Phase 2 human viewer disposable acceptance',target_type=TargetType.MANAGED,kodi_version='21.3',availability=TargetAvailability.UNAVAILABLE,health=HealthStatus.WARNING,connection_state=ConnectionState.DISCONNECTED))
ManagedInstanceService(f,novnc_phase1=True).create(target_id=target,selection=ExactRevisionSelection(load_novnc_phase1_recipe().recipe.definition_id,revision),instance_type=InstanceType.DISPOSABLE)
print(json.dumps({'target':str(target),'image':image,'revision':str(revision)}))
'''.replace('TARGET',target)
 oneoff('target-registration',code);save('private/target.json',json.loads((ROOT/'evidence/target-registration.log').read_text().splitlines()[-1]));start_stack('bootstrap');ready();login();mutate('provision','provision')
 c=client();ns=c.containers.list(all=True,filters={'label':'io.kodi-lab.instance-id='+target});assert len(ns)==1;n=ns[0];n.reload();assert not n.attrs['State']['Running'] and n.attrs['Image']==load('private/target.json')['image'];record('native','container',n.id);save('private/native.json',{'id':n.id,'image':n.attrs['Image'],'target':target})
 fixture=(OLD/'private/phase1-numbered-motion.mp4').read_bytes();put(n,'/home/kodi/.kodi/userdata','phase1-numbered-motion.mp4',fixture,1000,1000,0o644);save('evidence/fixture.json',{'sha256':hashlib.sha256(fixture).hexdigest(),'bytes':len(fixture)})
 print('One stopped managed disposable native provisioned',target,n.id)

def start_stack(tag,pin=None):
 c=client()
 if (ROOT/'private/services.json').exists():
  for role,e in load('private/services.json').items():
   x=c.containers.get(e['id']);assert x.labels=={**x.labels,**LABEL} and x.attrs['Image']==e['image']
   if x.attrs['State']['Running']:x.stop(timeout=5)
   (ROOT/f'evidence/{role}-{e["tag"]}-logs.txt').write_bytes(x.logs())
 frozen=None
 if pin:
  src=ROOT/f'private/pin-{tag}-source.json';src.write_text(json.dumps(pin));frozen=ROOT/f'private/pin-{tag}-root.json'
  assert not frozen.exists();subprocess.run(['sudo','-n','install','-o','root','-g','root','-m','0444',str(src),str(frozen)],check=True,timeout=3)
 services={}
 for role in ('broker','web'):
  volumes={STATE:{'bind':'/var/lib/kodi-lab','mode':'rw'},SOCKET:{'bind':'/run/kodi-lab','mode':'rw' if role=='broker' else 'ro'}};options={}
  if role=='broker':volumes['/var/run/docker.sock']={'bind':'/var/run/docker.sock','mode':'rw'};options['cap_add']=['CHOWN','DAC_OVERRIDE','FOWNER']
  else:options['ports']={'8100/tcp':('127.0.0.1',PORT)}
  if frozen:volumes[str(frozen)]={'bind':'/usr/share/kodi-lab/novnc-phase1-pin.json','mode':'ro'};options['entrypoint']=['python','-m','kodi_lab.runtime.novnc_qualification',role]
  x=c.containers.create(images()[role],name=f'klnovnc2-{role}-{tag}',network=NETWORK,volumes=volumes,read_only=True,tmpfs={'/tmp':'rw,noexec,nosuid,size=64m'},environment={'KODI_LAB_WEB_ALLOWED_HOSTS':'["127.0.0.1","192.168.2.191","localhost"]'},cap_drop=['ALL'],security_opt=['no-new-privileges:true'],init=True,labels={**LABEL,'io.kodi-lab.novnc-role':role},**options);record(role+'-'+tag,'container',x.id)
  if role=='web':c.networks.get('kodi-lab-managed-v1').connect(x)
  x.start();services[role]={'id':x.id,'image':images()[role],'tag':tag}
 save('private/services.json',services)

def ready():
 deadline=time.monotonic()+30
 with httpx.Client(trust_env=False,timeout=1) as h:
  while time.monotonic()<deadline:
   try:
    if h.get(f'http://127.0.0.1:{PORT}/login').status_code==200:return
   except httpx.HTTPError:pass
   time.sleep(.2)
 raise RuntimeError('Web readiness deadline')

def login():
 with httpx.Client(trust_env=False,timeout=3) as h:
  b=f'http://127.0.0.1:{PORT}';q=h.post(b+'/login',data={'password':(ROOT/'private/admin-password').read_text().strip()},headers={'Origin':b});assert q.status_code==303
  csrf=re.search('name="kodi-lab-csrf" content="([^"]+)"',h.get(b+'/').text).group(1);save('private/operator-session.json',{'token':h.cookies.get('kodi_lab_session'),'csrf':csrf})

def mutate(action,tag):
 intent=ROOT/f'private/{tag}-intent.json';assert not intent.exists(),tag;target=load('private/target.json')['target'];intent.write_text(json.dumps({'action':action,'target':target,'at':time.time()}));s=load('private/operator-session.json');b=f'http://127.0.0.1:{PORT}'
 with httpx.Client(trust_env=False,timeout=30) as h:q=h.post(b+f'/api/instances/{target}/{action}',json={},headers={'Origin':b,'Cookie':'kodi_lab_session='+s['token'],'X-Kodi-Lab-CSRF':s['csrf']})
 (ROOT/f'private/{tag}-response.json').write_text(q.text);assert q.status_code in (200,201,202),(q.status_code,q.text[:1000]);return q.json()

def put(n,directory,name,body,uid,gid,mode):
 out=io.BytesIO()
 with tarfile.open(fileobj=out,mode='w') as t:
  m=tarfile.TarInfo(name);m.size=len(body);m.uid=uid;m.gid=gid;m.mode=mode;t.addfile(m,io.BytesIO(body))
 assert n.put_archive(directory,out.getvalue())

def fence():
 c=client();e=load('private/native.json');n=c.containers.get(e['id']);n.reload();a=n.attrs
 assert a['Image']==e['image'] and a['Config']['Labels']['io.kodi-lab.instance-id']==e['target'] and not a['Mounts'] and not a['HostConfig']['PortBindings'];assert all(x.id==n.id for x in c.containers.list(filters={'label':'io.kodi-lab.managed=true'}));c.close();return n

def rpc(method,params=None):
 n=fence();assert n.attrs['State']['Running'];ip=n.attrs['NetworkSettings']['Networks']['kodi-lab-managed-v1']['IPAddress'];before=time.time()*1000
 with httpx.Client(trust_env=False,timeout=3) as h:q=h.post(f'http://{ip}:8080/jsonrpc',json={'jsonrpc':'2.0','id':1,'method':method,'params':params or {}})
 after=time.time()*1000;q.raise_for_status();v=q.json();assert 'error' not in v,v;return v['result'],{'sent':before,'received':after}

def status():
 s=load('private/operator-session.json')
 with httpx.Client(trust_env=False,timeout=2) as h:q=h.get(f'http://127.0.0.1:{PORT}/api/instances/'+load('private/target.json')['target'],cookies={'kodi_lab_session':s['token']});q.raise_for_status();return q.json()

def pin():
 n=fence();assert n.attrs['State']['Running'] and n.attrs['State']['Health']['Status']=='healthy';e=load('private/native.json');web=client().containers.get(load('private/services.json')['web']['id'])
 code="""import json
from uuid import UUID
from kodi_lab.config import Settings
from kodi_lab.storage.engine import create_database_engine,create_session_factory
from kodi_lab.application.novnc import CatalogViewAuthority
from kodi_lab.broker.novnc import ViewBinding
s=Settings(_env_file=None);f=create_session_factory(create_database_engine(s.database_url));b=ViewBinding('CID','IMAGE','START',());print(json.dumps(CatalogViewAuthority(f,{UUID('TARGET'):b}).resolve(UUID('TARGET')).identity))
""".replace('CID',n.id).replace('IMAGE',e['image']).replace('START',n.attrs['State']['StartedAt']).replace('TARGET',e['target'])
 x=web.exec_run(['python','-c',code]);assert x.exit_code==0,x.output.decode()[-1000:]
 value={'instance':e['target'],'container':n.id,'image':e['image'],'started':n.attrs['State']['StartedAt'],'identity':json.loads(x.output),'expires':time.time()+3600,'proxy_ip':c_network_gateway()};save('private/native-pin.json',value);return value

if __name__=='__main__':
 import sys
 {'initialize':initialize,'install':install,'register':register}[sys.argv[1]]()

def c_network_gateway():
 return client().networks.get("kodi-lab-managed-v1").attrs["IPAM"]["Config"][0]["Gateway"]
