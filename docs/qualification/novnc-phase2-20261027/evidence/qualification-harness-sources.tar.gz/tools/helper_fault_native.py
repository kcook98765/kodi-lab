"""Focused compound uncatchable native input-worker crash; neutral or fenced only."""
import os,time,traceback,json
os.environ['RUN_ID']='helper1-'
import lab,core as c,acceptance_support as a
from trial import Trial
trial=Trial.__new__(Trial)
try:
 trial.__init__('helper1',source=False);trial.start_view();c.browser.call('take');c.browser.call('focusCanvas');c.browser.call('key',value='a',hold=True);c.browser.call('down',x=440,y=285);c.wait(.15)
 held=a.xstate();assert held['keys'] and held['mask']&256;workers=a.workers();rows=a.ownership();lab.save('evidence/native-compound-crash-before.json',{'held':held,'workers':workers,'ownership':rows})
 targets=workers['processes'];code="import os,signal;from pathlib import Path\nrows="+repr(targets)+"\nfor r in rows:\n p=Path('/proc')/str(r['pid']);assert p.joinpath('stat').read_text().split(') ',1)[1].split()[19]==r['start']\nfor r in sorted(rows,key=lambda r:0 if r['args'][0]=='/usr/bin/X0tigervnc' else 1):os.kill(r['pid'],signal.SIGKILL)\n"
 q=lab.fence().exec_run(['/usr/bin/python3','-I','-B','-c',code],user='1000:1000');assert q.exit_code==0;c.wait(4)
 native=a.xstate();rows=a.ownership();workers=a.workers();blocked,ms,_=a.remote('left');held_after=bool(native['keys'] or native['mask']&0x1f00)
 if held_after:assert rows and blocked.get('isError')
 else:assert not rows and not blocked.get('isError')
 lab.save('evidence/native-compound-crash-after.json',{'held_after':held_after,'native':native,'workers':workers,'ownership':rows,'agent_rejected':bool(blocked.get('isError')),'agent_response_ms':ms})
 trial.stop_native();assert not a.ownership();lab.save('evidence/native-compound-crash-recovery.json',{'exact_native_stop':True,'container':lab.fence().id,'ownership':a.ownership(),'stopped':not lab.fence().attrs['State']['Running']});c.browser.call('resetInput');trial.completed=True
except BaseException as error:
 lab.save('evidence/helper1-error.json',{'error':str(error),'traceback':traceback.format_exc()});print(traceback.format_exc(),flush=True)
finally:trial.close()
assert trial.completed
