"""Exact campaign resources only, after recovery archives and authority retirement."""
import os,json,hashlib,secrets,subprocess,time,signal
from pathlib import Path
import docker,httpx
import lab
root=lab.ROOT;c=lab.client();before={x['Id'] for x in lab.load('private/inventory-before.json')};entries=[json.loads(x) for x in (root/'private/resources.jsonl').read_text().splitlines()];receipt={'at':time.time(),'removed_containers':[],'removed_images':[],'removed_volumes':[],'removed_networks':[],'stopped_processes':[]}
assert not (root/'evidence/cleanup.json').exists()
n=lab.fence();assert not n.attrs['State']['Running'] and n.id not in before
for p in (root/'evidence').glob('browser-identity-*.json'):
 x=json.loads(p.read_text());proc=Path('/proc')/str(x['root']['pid'])
 try:live=int(proc.joinpath('stat').read_text().split(') ',1)[1].split()[19])==x['root']['start']
 except FileNotFoundError:live=False
 assert not live,p
for directory,tag in [('/home/kodi/.kodi/userdata','userdata'),('/var/log','system-logs')]:
 stream,_=n.get_archive(directory);p=root/f'private/native-final-{tag}.tar'
 with p.open('wb') as f:
  for chunk in stream:f.write(chunk)
 receipt['native_'+tag+'_archive']={'file':'private/'+p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
(root/'private/native-final-logs.txt').write_bytes(n.logs());lab.save('private/native-final-inspect.json',n.attrs)
subprocess.run([lab.PY,str(root/'tools/phase2_admin.py'),'revoke'],check=True,stdout=(root/'evidence/revoke.log').open('w'),stderr=subprocess.STDOUT,timeout=15)
token=(root/'private/mcp-token').read_text().strip();assert token
with httpx.Client(trust_env=False,timeout=3) as h:
 q=h.post(a_base:=f'http://127.0.0.1:{lab.PORT}/mcp',headers={'Authorization':'Bearer '+token,'Accept':'application/json, text/event-stream','MCP-Protocol-Version':'2025-11-25','Mcp-Method':'tools/call','Mcp-Name':'inspect_ui_state'},json={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':'inspect_ui_state','arguments':{'target_id':lab.load('private/target.json')['target']}}})
assert q.status_code==401;q_status=q.status_code;(root/'private/mcp-token').write_text('');lab.save('evidence/credential-retirement.json',{'at':time.time(),'identity':lab.load('private/mcp-identity.json'),'supported_revocation':True,'old_token_HTTP':q_status,'token_file_emptied':True})
lab.mutate('deprovision','deprovision-final');
try:c.containers.get(n.id);raise AssertionError('Exact native deprovision incomplete')
except docker.errors.NotFound:pass
receipt['supported_native_deprovision']=n.id
# All Web sessions belong only to this freshly initialized test catalog.
sessions={}
for p in (root/'private').glob('*session*.json'):
 x=json.loads(p.read_text())
 if isinstance(x,dict) and x.get('token'):sessions[p.name]=x['token']
code="""import secrets
from kodi_lab.config import Settings
from kodi_lab.storage.engine import create_database_engine,create_session_factory
from kodi_lab.auth.service import WebAuthenticationService
WebAuthenticationService(create_session_factory(create_database_engine(Settings(_env_file=None).database_url))).set_password(secrets.token_urlsafe(48));print('Isolated catalog sessions retired')
"""
x=c.containers.get(lab.load('private/services.json')['web']['id']).exec_run(['python','-c',code]);assert x.exit_code==0
statuses={}
with httpx.Client(trust_env=False,timeout=3) as h:
 for name,token in sessions.items():
  q=h.get(f'http://127.0.0.1:{lab.PORT}/api/instances/'+lab.load('private/target.json')['target'],cookies={'kodi_lab_session':token});statuses[name]=q.status_code;assert q.status_code==401
(root/'private/admin-password').write_text('');lab.save('evidence/session-retirement.json',{'all_isolated_sessions_retired':True,'cookie_reuse_statuses':statuses,'plaintext_password_emptied':True})
# Close services before archiving catalog and removing its volumes.
for e in entries:
 if e['kind']!='container' or e['id']==n.id:continue
 try:x=c.containers.get(e['id'])
 except docker.errors.NotFound:continue
 x.reload();assert x.id not in before and x.labels.get('io.kodi-lab.novnc-phase2')=='20261027'
 if x.attrs['State']['Running']:x.stop(timeout=5)
 (root/f'private/final-{e["role"]}-logs.txt').write_bytes(x.logs())
 if e['role'].startswith(('broker','web')):(root/f'evidence/final-{e["role"]}-logs.txt').write_bytes(x.logs())
web=c.containers.get(lab.load('private/services.json')['web']['id']);stream,_=web.get_archive('/var/lib/kodi-lab');archive=root/'private/catalog-recovery.tar'
with archive.open('wb') as f:
 for chunk in stream:f.write(chunk)
receipt['catalog_archive']={'file':'private/catalog-recovery.tar','sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size}
# PID + start-time + exact command fencing. No process-name-wide kill.
processes=[lab.load('private/test-proxy.json')]+[json.loads(x) for x in (root/'private/event-watch-identities.jsonl').read_text().splitlines()]
for ident in processes:
 p=Path('/proc')/str(ident['pid'])
 try:
  same=p.joinpath('stat').read_text().split(') ',1)[1].split()[19]==str(ident['start'])
  if same:
   cmd=p.joinpath('cmdline').read_bytes();assert str(root).encode() in cmd;os.kill(ident['pid'],signal.SIGTERM);receipt['stopped_processes'].append(ident)
 except FileNotFoundError:pass
for e in entries:
 if e['kind']!='container' or e['id']==n.id:continue
 try:x=c.containers.get(e['id'])
 except docker.errors.NotFound:continue
 x.reload();assert x.id not in before and x.labels.get('io.kodi-lab.novnc-phase2')=='20261027' and not x.attrs['State']['Running'];x.remove(v=False);receipt['removed_containers'].append(x.id)
for kind in ('network','volume'):
 for e in entries:
  if e['kind']!=kind:continue
  if kind=='network':
   x=c.networks.get(e['id']);x.reload();assert x.attrs['Labels']==lab.LABEL and not x.attrs.get('Containers');x.remove();receipt['removed_networks'].append(e['id'])
  else:
   x=c.volumes.get(e['id']);assert x.attrs['Labels']==lab.LABEL and not c.containers.list(all=True,filters={'volume':x.name});x.remove();receipt['removed_volumes'].append(e['id'])
for iid in dict.fromkeys(e['id'] for e in entries if e['kind']=='image'):
 x=c.images.get(iid);assert x.labels.get('io.kodi-lab.novnc-phase2')=='20261027' or iid==lab.load('private/target.json')['image'];assert not c.containers.list(all=True,filters={'ancestor':iid});assert not any(o['Image']==iid for o in lab.load('private/inventory-before.json'));c.images.remove(iid,noprune=True);receipt['removed_images'].append(iid)
# Isolated reviewer credential is retired by the final audit after all reviews.
lab.save('evidence/cleanup.json',receipt);print(json.dumps(receipt,indent=2))
