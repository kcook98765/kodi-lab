"""Existing JPEG Web UI and expired-ticket/replay negatives in Firefox."""
import os,time,traceback,json
from uuid import uuid4
os.environ['RUN_ID']='jpeg4-'
import lab,core as c,acceptance_support as a
from trial import Trial
trial=Trial.__new__(Trial)
def ev(expression):return c.browser.call('evaluate',expression=expression)
try:
 trial.__init__('jpeg4',source=False);target=lab.load('private/target.json')['target']
 c.browser.call('goto',url='https://localhost:18109/instances/'+target);c.wait(1)
 ready=ev("(()=>({enabled:!document.querySelector('[data-live-start]').disabled}))()");assert ready['enabled']
 c.browser.call('click',selector='[data-live-start]');c.wait(7)
 first=ev("(()=>{const i=document.querySelector('[data-live-image]');return {src:i.src,width:i.naturalWidth,height:i.naturalHeight,hidden:i.hidden,status:document.querySelector('[data-live-status]').textContent};})()")
 assert first['width']==640 and first['height']==360 and not first['hidden'],first
 c.wait(3);second=ev("(()=>{const i=document.querySelector('[data-live-image]');return {src:i.src,width:i.naturalWidth,height:i.naturalHeight,status:document.querySelector('[data-live-status]').textContent};})()")
 assert first['src']!=second['src'];c.browser.call('click',selector='[data-live-stop]');c.wait(.5);stop=ev("(()=>({hidden:document.querySelector('[data-live-image]').hidden,status:document.querySelector('[data-live-status]').textContent}))()")
 assert stop['hidden'];lab.save('evidence/native-JPEG-browser.json',{'first':first,'second':second,'stop':stop,'noVNC_active':bool(a.ownership())});assert not a.ownership();a.screenshot('jpeg4-after-JPEG');trial.completed=True
except BaseException as error:
 lab.save('evidence/jpeg4-error.json',{'error':str(error),'traceback':traceback.format_exc()});print(traceback.format_exc(),flush=True)
finally:trial.close()
assert trial.completed
