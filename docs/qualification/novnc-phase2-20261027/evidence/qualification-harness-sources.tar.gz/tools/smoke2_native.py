"""First bounded native human-Web path check; always stop exact test native."""
import os,time,json,subprocess,traceback,hashlib
from pathlib import Path
os.environ['RUN_ID']='smoke2-'
import lab,core as c
from browser_memory import Browser
from drivers import Source
import acceptance_support as a
completed=False

def ledger(event):
 n=lab.fence()
 with (lab.ROOT/'evidence/native-active-ledger.jsonl').open('a') as f:f.write(json.dumps({'event':event,'at':time.time(),'container':n.id,'state':n.attrs['State']})+'\n')

try:
 c.mon.used=lab.load('evidence/active-budget.json')['monitor_cumulative_seconds'];c.mon.start();c.browser=Browser('smoke2','firefox');baseline=c.stage('blank',15);c.browser_baseline=baseline['tree_rss_smaps_mib']['median']
 lab.mutate('start','start-smoke2');ledger('start-smoke2');deadline=time.monotonic()+30
 while time.monotonic()<deadline:
  c.mon.check();n=lab.fence()
  if n.attrs['State'].get('Health',{}).get('Status')=='healthy' and lab.status()['usability_state']=='usable':break
  c.wait(.25)
 else:raise RuntimeError('Native startup readiness')
 pin=lab.pin();lab.save('private/operator-session-bootstrap.json',lab.load('private/operator-session.json'));lab.start_stack('smoke2',pin);lab.ready();lab.login()
 assert (lab.ROOT/'private/mcp-token').read_text().strip()

 deadline=time.monotonic()+30
 while time.monotonic()<deadline:
  if lab.status()['usability_state']=='usable':break
  c.wait(.25)
 else:raise RuntimeError('Pinned Web runtime readiness')
 c.source=Source(lab.fence());assert (c.source.info['width'],c.source.info['height'])==(640,360)
 lab.save('evidence/native-initial-geometry.json',c.source.info)
 lab.save('evidence/browser-page-smoke2.json',c.browser.call('page'));c.stage('inactive',5)
 a.screenshot('smoke2-off')
 lab.save('evidence/browser-start-smoke2.json',c.browser.call('start'));a.flags(False,'smoke2-view-only');c.stage('view-only',5)
 inspect,elapsed,_=a.mcp_raw('inspect_ui_state',{'target_id':pin['instance']});lab.save('evidence/agent-inspection-smoke2.json',{'isError':inspect.get('isError',False),'elapsed_ms':elapsed,'text':[v.get('text','')[:1000] for v in inspect.get('content',[]) if v.get('type')=='text']});assert not inspect.get('isError')
 lab.save('evidence/take-smoke2.json',c.browser.call('take'));a.flags(True,'smoke2-interactive');c.stage('interactive',3)
 blocked,elapsed,_=a.remote('right');lab.save('evidence/agent-input-blocked-smoke2.json',{'result':blocked,'elapsed_ms':elapsed});assert blocked.get('isError')
 a.screenshot('smoke2-controlled')
 before=a.xstate();c.browser.call('key',value='a',hold=True);c.wait(.2);held=a.xstate();c.browser.call('key',value='a',up=True);c.wait(.2);after=a.xstate();assert held['keys'] and not after['keys'];lab.save('evidence/native-key-smoke2.json',{'before':before,'held':held,'after':after})
 lab.save('evidence/release-smoke2.json',c.browser.call('release'));a.flags(False,'smoke2-released')
 resumed,elapsed,_=a.remote('left');lab.save('evidence/agent-input-resumed-smoke2.json',{'result':resumed,'elapsed_ms':elapsed});assert not resumed.get('isError')
 c.browser.call('photo',name='smoke2-human-viewer');c.browser.call('stop');a.clean('smoke2');c.stage('disconnected',5);completed=True
except BaseException as error:
 lab.save('evidence/smoke2-error.json',{'error':str(error),'traceback':traceback.format_exc()});print(traceback.format_exc(),flush=True)
finally:
 if c.browser:
  try:c.browser.close()
  except Exception as error:lab.save('evidence/smoke2-browser-close-error.json',{'error':repr(error)})
 try:c.mon.stop_native('stop-smoke2');ledger('stop-smoke2')
 except Exception as error:lab.save('evidence/smoke2-native-stop-error.json',{'error':repr(error)})
 if c.source:
  try:c.source.finish('smoke2')
  except Exception as error:lab.save('evidence/smoke2-source-close-error.json',{'error':repr(error)})
 c.mon.close();lab.save('evidence/active-budget.json',{'monitor_cumulative_seconds':c.mon.used});lab.save('evidence/smoke2-result.json',{'completed':completed,'native_stopped':not lab.fence().attrs['State']['Running'],'native_accounted_seconds':c.mon.used,'safety_abort':c.mon.abort.is_set(),'reason':c.mon.reason})
 print('Smoke completed',completed,flush=True)
assert completed
