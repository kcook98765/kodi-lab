from pathlib import Path
import os,subprocess,json,sys
ROOT=Path(__file__).resolve().parents[1];r=ROOT/'review';tag=sys.argv[1];env=dict(os.environ)
for key,folder in [('XDG_CONFIG_HOME','config'),('XDG_DATA_HOME','data'),('XDG_CACHE_HOME','cache'),('XDG_STATE_HOME','state')]:env[key]=str(r/folder)
env['OPENCODE_CONFIG']=str(r/'config/opencode/opencode.json')
with (r/(tag+'.jsonl')).open('w') as out,(r/(tag+'.stderr')).open('w') as err:
 p=subprocess.run(['opencode','run','--pure','--agent','phase2-review','--format','json','--dir','/home/kyle/kodi-lab-worktrees/novnc-phase2-20261027',(r/('request-'+tag+'.txt')).read_text()],env=env,stdout=out,stderr=err,timeout=300)
texts=[]
for line in (r/(tag+'.jsonl')).read_text().splitlines():
 e=json.loads(line)
 if e.get('type')=='text':texts.append(e.get('part',{}).get('text',''))
(r/('REVIEW-'+tag.upper()+'.md')).write_text('\n\n'.join(texts))
print(json.dumps({'exit':p.returncode,'texts':len(texts),'review':str(r/('REVIEW-'+tag.upper()+'.md'))}));assert p.returncode==0 and texts
