"""Qualification-only fixture/measurement helpers; no production capabilities."""
import base64,json,time
from uuid import uuid4
import httpx
import lab
BASE=f'http://127.0.0.1:{lab.PORT}'
def mcp_raw(name,args):
 token=(lab.ROOT/'private/mcp-token').read_text().strip();began=time.time()*1000
 with httpx.Client(trust_env=False,timeout=6) as h:
  r=h.post(BASE+'/mcp',headers={'Authorization':'Bearer '+token,'Accept':'application/json, text/event-stream','Accept-Encoding':'identity','MCP-Protocol-Version':'2025-11-25','Mcp-Method':'tools/call','Mcp-Name':name},json={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':name,'arguments':args}})
 elapsed=time.time()*1000-began;assert len(r.content)<=8*1024*1024
 if r.headers.get('content-type','').startswith('text/event-stream'):
  records=[json.loads(x[6:]) for x in r.text.splitlines() if x.startswith('data: ')];assert len(records)==1;body=records[0]
 else:body=r.json()
 assert r.status_code==200 and 'error' not in body,(r.status_code,body.get('error'))
 return body['result'],elapsed,began

def mcp(client,name,args):
 result,elapsed,began=mcp_raw(name,args);assert not result.get('isError'),result.get('structuredContent') or [x.get('text','')[:1000] for x in result.get('content',[]) if x.get('type')=='text'];return result,elapsed,began

def remote(action):return mcp_raw('remote_action',{'target_id':lab.load('private/target.json')['target'],'request_id':str(uuid4()),'action':action})
def web_post(path,body):
 s=lab.load('private/operator-session.json')
 with httpx.Client(trust_env=False,timeout=8) as h:r=h.post(BASE+path,json=body,headers={'Origin':BASE,'Cookie':'kodi_lab_session='+s['token'],'X-Kodi-Lab-CSRF':s['csrf']})
 return r

def ui():return lab.rpc('GUI.GetProperties',{'properties':['currentwindow','currentcontrol']})[0]

def native_code(code):
 n=lab.fence();assert n.attrs['State']['Running'];q=n.exec_run(['/usr/bin/python3','-I','-B','-c',code],user='1000:1000');assert q.exit_code==0,q.output.decode(errors='replace')[-600:];return json.loads(q.output)

def ownership():
 target=lab.load('private/target.json')['target'];code="""import sqlite3,json
c=sqlite3.connect('file:/var/lib/kodi-lab/database/kodi-lab.db?mode=ro',uri=True);c.row_factory=sqlite3.Row;c.execute('pragma query_only=on');print(json.dumps([dict(x) for x in c.execute('select instance_id,attempt,mode,state,expires_at,absolute_expires_at,broker_id,exec_id from novnc_sessions where instance_id=?',('TARGET',))]))
""".replace('TARGET',target)
 x=lab.client().containers.get(lab.load('private/services.json')['web']['id']).exec_run(['python','-c',code]);assert x.exit_code==0;return json.loads(x.output)

XSTATE=r'''import ctypes,json
x=ctypes.CDLL('libX11.so.6');d=ctypes.c_void_p
x.XOpenDisplay.argtypes=[ctypes.c_char_p];x.XOpenDisplay.restype=d
x.XDefaultRootWindow.argtypes=[d];x.XDefaultRootWindow.restype=ctypes.c_ulong
x.XQueryKeymap.argtypes=[d,ctypes.c_void_p]
x.XQueryPointer.argtypes=[d,ctypes.c_ulong,ctypes.POINTER(ctypes.c_ulong),ctypes.POINTER(ctypes.c_ulong),ctypes.POINTER(ctypes.c_int),ctypes.POINTER(ctypes.c_int),ctypes.POINTER(ctypes.c_int),ctypes.POINTER(ctypes.c_int),ctypes.POINTER(ctypes.c_uint)]
x.XCloseDisplay.argtypes=[d]
p=x.XOpenDisplay(b':99');assert p
keys=(ctypes.c_ubyte*32)();x.XQueryKeymap(p,keys);roots=[ctypes.c_ulong(),ctypes.c_ulong()];coords=[ctypes.c_int() for _ in range(4)];mask=ctypes.c_uint();assert x.XQueryPointer(p,x.XDefaultRootWindow(p),*[ctypes.byref(v) for v in (*roots,*coords,mask)])
print(json.dumps({'keys':[k for k in range(8,256) if keys[k//8]&(1<<(k%8))],'root_xy':[coords[0].value,coords[1].value],'mask':mask.value}));x.XCloseDisplay(p)
'''
def xstate():return native_code(XSTATE)

def workers():
 return native_code(r'''import json,stat
from pathlib import Path
rows=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  args=[x.decode(errors='replace') for x in p.joinpath('cmdline').read_bytes().split(b'\0') if x]
  if '/usr/bin/X0tigervnc' in args or ('/usr/local/lib/kodi-lab-novnc-view.py' in args and not any(x.startswith('--probe') for x in args)):
   rows.append({'pid':int(p.name),'start':p.joinpath('stat').read_text().split(') ',1)[1].split()[19],'args':args})
 except FileNotFoundError:pass
sockets=[]
for p in Path('/run/kodi').glob('view-*/rfb.sock'):
 s=p.stat();d=p.parent.stat();sockets.append({'path':str(p),'mode':oct(stat.S_IMODE(s.st_mode)),'uid':s.st_uid,'directory_mode':oct(stat.S_IMODE(d.st_mode))})
print(json.dumps({'processes':rows,'sockets':sockets,'tcp_listeners':[l.split()[1] for l in Path('/proc/net/tcp').read_text().splitlines()[1:] if l.split()[3]=='0A']}))
''')

def flags(interactive,tag):
 value=workers();servers=[p for p in value['processes'] if p['args'][0]=='/usr/bin/X0tigervnc'];assert len(servers)==1
 args=servers[0]['args'];assert '-FrameRate=2' in args and '-rfbport=-1' in args
 for cap in ('AcceptKeyEvents','AcceptPointerEvents'):assert f'-{cap}={int(interactive)}' in args
 for cap in ('AcceptCutText','SendCutText','AcceptSetDesktopSize','SetPrimary','SendPrimary'):assert f'-{cap}=0' in args
 assert len(value['sockets'])==1 and value['sockets'][0]['mode']=='0o600' and value['sockets'][0]['directory_mode']=='0o700'
 assert not any(x.endswith(':170C') for x in value['tcp_listeners'])
 lab.save('evidence/native-flags-'+tag+'.json',value);return value

def clean(tag,timeout=5):
 began=time.monotonic();deadline=began+timeout
 while time.monotonic()<deadline:
  value=workers();rows=ownership()
  if not value['processes'] and not value['sockets'] and not rows:
   result={'cleanup_ms':(time.monotonic()-began)*1000,'workers':value,'ownership':rows,'xstate':xstate()};lab.save('evidence/cleanup-'+tag+'.json',result);return result
  time.sleep(.05)
 raise RuntimeError('Native cleanup not proven: '+json.dumps({'workers':value,'rows':rows}))

def screenshot(tag):
 target=lab.load('private/target.json')['target'];r=web_post('/api/instances/'+target+'/screenshots',{});assert r.status_code==200,(r.status_code,r.text[:600])
 s=lab.load('private/operator-session.json')
 with httpx.Client(trust_env=False,timeout=4) as h:q=h.get(BASE+'/api/instances/'+target+'/screenshots/latest',cookies={'kodi_lab_session':s['token']})
 q.raise_for_status();assert q.content.startswith(b'\x89PNG');(lab.ROOT/f'evidence/independent-still-{tag}.png').write_bytes(q.content);import struct
 width,height=struct.unpack('>II',q.content[16:24]);assert (width,height)==(1280,720)
 result={'capture_status':r.json(),'geometry':[width,height],'bytes':len(q.content),'source':'existing independent X11 screenshot path, not VNC'};lab.save('evidence/independent-still-'+tag+'.json',result);return result
