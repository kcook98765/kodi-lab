// Firefox's native loopback WebDriver BiDi; no browser sandbox/cache overrides.
const fs=require('fs'),path=require('path'),{spawn}=require('child_process');
const ROOT=path.resolve(__dirname,'..');
const nap=ms=>new Promise(r=>setTimeout(r,ms));
class Firefox {
 constructor(tag){this.tag=tag;this.serial=0;this.pending=new Map();this.events=[];}
 async launch(){
  const bin=fs.realpathSync('/snap/firefox/current/usr/lib/firefox/firefox');
  this.profile=path.join(ROOT,'private','profiles',this.tag);fs.mkdirSync(this.profile,{recursive:true,mode:0o700});
  const prefs={'app.update.auto':false,'app.update.enabled':false,'datareporting.policy.dataSubmissionEnabled':false,'toolkit.telemetry.enabled':false,'browser.startup.homepage':'about:blank','startup.homepage_welcome_url':'','browser.newtabpage.enabled':false,'browser.shell.checkDefaultBrowser':false,'extensions.update.enabled':false};
  fs.writeFileSync(path.join(this.profile,'user.js'),Object.entries(prefs).map(([k,v])=>`user_pref(${JSON.stringify(k)}, ${JSON.stringify(v)});`).join('\n'));
  require('child_process').execFileSync('certutil',['-N','-d','sql:'+this.profile,'--empty-password']);
  require('child_process').execFileSync('certutil',['-A','-d','sql:'+this.profile,'-n','Kodi Lab Phase2 disposable CA','-t','C,,','-i',path.join(ROOT,'private/tls/ca.crt')]);
  const args=['--headless','--no-remote','--profile',this.profile,'--remote-debugging-port=0','about:blank'];
  const log=fs.createWriteStream(path.join(ROOT,'evidence',`firefox-${this.tag}.stderr`));
  this.child=spawn(bin,args,{env:{...process.env,XDG_CONFIG_HOME:path.join(this.profile,'xdg-config'),XDG_CACHE_HOME:path.join(this.profile,'xdg-cache'),MOZ_CRASHREPORTER_DATA_DIRECTORY:path.join(this.profile,'crash-reports')},stdio:['ignore','pipe','pipe']});
  let stderr='';this.child.stderr.on('data',c=>{log.write(c);stderr=(stderr+c.toString()).slice(-20000);});this.child.stdout.on('data',c=>log.write(c));this.log=log;
  let endpoint;for(let i=0;i<200;i++){const m=stderr.match(/WebDriver BiDi listening on (ws:\/\/[^\s]+)/);if(m){endpoint=m[1];break;}if(this.child.exitCode!==null)throw Error('Firefox exited before BiDi '+this.child.exitCode);await nap(50);}
  if(!endpoint)throw Error('Firefox BiDi startup deadline');
  this.socket=new WebSocket(endpoint+'/session');
  await new Promise((resolve,reject)=>{this.socket.addEventListener('open',resolve,{once:true});this.socket.addEventListener('error',()=>reject(Error('BiDi connection error')),{once:true});});
  this.socket.addEventListener('message',e=>{const v=JSON.parse(e.data);if(v.id!==undefined){const p=this.pending.get(v.id);if(p){clearTimeout(p.timer);this.pending.delete(v.id);v.type==='error'?p.reject(Error(v.error+': '+v.message)):p.resolve(v.result);}}else if(this.events.length<30)this.events.push({method:v.method});});
  const session=await this.command('session.new',{capabilities:{alwaysMatch:{acceptInsecureCerts:false}}});
  const tree=await this.command('browsingContext.getTree',{});this.context=tree.contexts[0].context;
  await this.command('browsingContext.setViewport',{context:this.context,viewport:{width:1440,height:1000},devicePixelRatio:1});
  this.info={engine:'firefox',browser:session.capabilities.browserVersion,capabilities:session.capabilities,root_pid:this.child.pid,binary:bin,args,prefs,endpoint_scope:'Firefox native BiDi loopback only; ephemeral port'};
  return this.info;
 }
 command(method,params){const id=++this.serial;return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{this.pending.delete(id);reject(Error('BiDi command deadline '+method));},8000);this.pending.set(id,{resolve,reject,timer});this.socket.send(JSON.stringify({id,method,params}));});}
 async evaluate(fn,arg){
  const source=typeof fn==='function'?`(${fn.toString()})(${JSON.stringify(arg===undefined?null:arg)})`:fn;
  const r=await this.command('script.evaluate',{expression:`(async()=>JSON.stringify(await (${source})))()`,target:{context:this.context},awaitPromise:true,resultOwnership:'none'});
  if(r.type!=='success')throw Error('Firefox script exception: '+(r.exceptionDetails?.text||JSON.stringify(r).slice(0,400)));
  return r.result.type==='undefined'?null:JSON.parse(r.result.value);
 }
 async goto(url){return this.command('browsingContext.navigate',{context:this.context,url,wait:'complete'});}
 async setCookie(token){return this.command('storage.setCookie',{cookie:{name:'kodi_lab_session',value:{type:'string',value:token},domain:'localhost',path:'/',httpOnly:true,secure:true,sameSite:'strict'}});}
 async closePage(){
  // Keep one blank document so browser lifetime stays separate from tab closure.
  const blank=await this.command('browsingContext.create',{type:'tab',background:true});
  await this.command('browsingContext.setViewport',{context:blank.context,viewport:{width:1440,height:1000},devicePixelRatio:1});
  const old=this.context;await this.command('browsingContext.close',{context:old});this.context=blank.context;
 }
 async close(){
  if(this.socket?.readyState===WebSocket.OPEN){try{await this.command('browser.close',{});}catch(e){}this.socket.close();}
  if(this.child?.exitCode===null){for(let i=0;i<60&&this.child.exitCode===null;i++)await nap(50);}
  if(this.child?.exitCode===null){this.child.kill('SIGTERM');for(let i=0;i<40&&this.child.exitCode===null;i++)await nap(50);}
  if(this.child?.exitCode===null)throw Error('Firefox remains alive');
  if(this.log)this.log.end();return {closed:true,exitCode:this.child?.exitCode};
 }
}
module.exports={Firefox};
