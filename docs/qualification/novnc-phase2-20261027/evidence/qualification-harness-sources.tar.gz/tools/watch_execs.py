"""Retain exact Docker native exec identities without command text or values."""
import hashlib,json,os,signal,time
from pathlib import Path
import lab
signal.signal(signal.SIGTERM,lambda *_:exit(0));signal.alarm(1900)
identity={'pid':os.getpid(),'start':Path('/proc/self/stat').read_text().split(') ',1)[1].split()[19],'at':time.time()}
lab.save('private/event-watch.json',identity)
with (lab.ROOT/'private/event-watch-identities.jsonl').open('a') as f:f.write(json.dumps(identity)+'\n')
c=lab.client();native=lab.load('private/native.json')['id'];since=int(time.time())-2
with (lab.ROOT/'evidence/native-exec-events.jsonl').open('a') as f:
 for e in c.api.events(since=since,filters={'container':native},decode=True):
  action=e.get('Action','');a=e.get('Actor',{}).get('Attributes',{});eid=a.get('execID')
  if not eid:continue
  kind=('proof' if '--probe' in action else 'view') if '/usr/local/lib/kodi-lab-novnc-view.py' in action else ('source' if 'Read-only X11 wire ROI observer' in action else 'other')
  f.write(json.dumps({'timeNano':e.get('timeNano'),'container':native,'exec':eid,'event':action.split(':',1)[0],'kind':kind,'action_sha256':hashlib.sha256(action.encode()).hexdigest()})+'\n');f.flush();os.fsync(f.fileno())
